from __future__ import annotations

from typing import Callable, Optional

import numpy as np
import pandas as pd

from .costs import CostEngine
from .data import detect_and_adjust_splits, strict_intersection_panel
from .indicators import FEATURES, add_indicators_by_symbol
from .level_a import LevelAOptimizer, LevelATuner
from .level_b import LevelBOptimizer, LevelBTuner
from .models import BacktestResult, CostConfig, OptimizationConfig, TuningConfig
from .risk import shrinkage_covariance
from .signals import SignalEngine
from .utils import annualized_volatility, calmar_ratio, cagr, max_drawdown, sharpe_ratio


def _emit(progress_cb: Optional[Callable[[int, str], None]], percent: float, text: str) -> None:
    if progress_cb is not None:
        progress_cb(int(round(percent)), text)


def _emit_snapshot(snapshot_cb: Optional[Callable[[dict], None]], payload: dict) -> None:
    if snapshot_cb is not None:
        snapshot_cb(payload)



def run_backtest(
    frame: pd.DataFrame,
    config: OptimizationConfig,
    cost_config: CostConfig,
    tuning: TuningConfig,
    progress_cb: Optional[Callable[[int, str], None]] = None,
    log_cb: Optional[Callable[[str, str], None]] = None,
    snapshot_cb: Optional[Callable[[dict], None]] = None,
) -> BacktestResult:
    cost_engine = CostEngine(cost_config)
    signal_engine = SignalEngine(config.z_window, config.z_clip, config.mu_min)

    _emit(progress_cb, 6, 'Корректировка корпоративных действий')
    adjusted_frame, split_events = detect_and_adjust_splits(frame)
    split_count = len(split_events)
    if log_cb is not None:
        log_cb('Запуск обработки сплитов и корпоративных действий', 'INFO')
        if split_events:
            grouped: dict[str, list] = {}
            for event in split_events:
                grouped.setdefault(event.symbol, []).append(event)
            for symbol, events in grouped.items():
                preview = ', '.join(f"{item.date.date()} ×{item.factor:g}" for item in events[:4])
                suffix = '' if len(events) <= 4 else f' и ещё {len(events) - 4}'
                log_cb(f"Обнаружены и скорректированы сплиты для {symbol}: {preview}{suffix}", 'WARN')
        else:
            log_cb('Сплиты не обнаружены', 'INFO')

    _emit(progress_cb, 12, 'Расчёт индикаторов')
    prepared = add_indicators_by_symbol(adjusted_frame, max_workers=config.max_workers)
    prepared = prepared.dropna(subset=FEATURES + ['Close']).reset_index(drop=True)

    _emit(progress_cb, 18, 'Построение согласованной панели цен')
    price_panel = strict_intersection_panel(prepared, price_column='Close')
    symbols = sorted(price_panel.columns.tolist())
    all_dates = price_panel.index
    split_point = int(len(all_dates) * config.train_ratio)
    split_point = max(config.calib_window + config.horizon + 5, min(split_point, len(all_dates) - 80))
    train_dates = all_dates[:split_point]
    test_dates = all_dates[split_point:]
    returns = price_panel.pct_change().dropna()

    indicator_frames: dict[str, pd.DataFrame] = {}
    for symbol in symbols:
        data = prepared[prepared['Symbol'] == symbol].copy()
        data = data.set_index('Date').sort_index().reindex(all_dates)
        indicator_frames[symbol] = signal_engine.build_feature_frame(data)

    if log_cb is not None:
        log_cb(
            f"Календарь после выравнивания: {all_dates[0].date()} — {all_dates[-1].date()} | дней: {len(all_dates)}",
            'INFO',
        )
        log_cb(
            f"Разделение по времени: обучение {len(train_dates)} дней, тест {len(test_dates)} дней. Бэктест нужен для проверки качества модели вне обучающего отрезка.",
            'INFO',
        )

    if tuning.enabled_a:
        if log_cb is not None:
            log_cb('Подбор гиперпараметров уровня A через Optuna', 'INFO')
        try:
            train_tail = _build_level_a_windows(indicator_frames, train_dates, config.calib_window)
            config = LevelATuner(config).tune(
                train_tail,
                tuning.trials_a,
                config.seed,
                progress_cb=lambda trial, total, best: _emit(
                    progress_cb,
                    18 + 10 * (trial / max(total, 1)),
                    f'Optuna A: испытание {trial}/{total}, лучший критерий {best:.4f}',
                ),
            )
            if log_cb is not None:
                log_cb('Подбор гиперпараметров уровня A завершён', 'READY')
        except Exception as exc:
            if log_cb is not None:
                log_cb(f'Подбор уровня A пропущен из-за ошибки: {exc}', 'WARN')
    else:
        _emit(progress_cb, 28, 'Optuna уровня A пропущен')

    level_a = LevelAOptimizer(config)
    a_weights = {symbol: np.ones(len(FEATURES), dtype=float) / len(FEATURES) for symbol in symbols}
    a_history: list[dict] = []
    weight_snapshots: dict[str, list[np.ndarray]] = {symbol: [] for symbol in symbols}

    def calibrate_level_a(end_date: pd.Timestamp, start_pct: float, end_pct: float, label: str) -> None:
        end_loc = all_dates.get_loc(end_date)
        start_loc = max(0, end_loc - config.calib_window + 1)
        window_dates = all_dates[start_loc : end_loc + 1]
        n_symbols = max(len(symbols), 1)
        span = max(end_pct - start_pct, 0.5)
        for idx, symbol in enumerate(symbols):
            base = start_pct + span * (idx / n_symbols)
            limit = start_pct + span * ((idx + 1) / n_symbols)
            try:
                window_frame = indicator_frames[symbol].loc[window_dates].dropna(subset=FEATURES + ['Close'])
                if len(window_frame) < max(config.calib_window // 3, len(FEATURES) * 8):
                    weights = np.ones(len(FEATURES), dtype=float) / len(FEATURES)
                    evaluation = {'objective': 0.0, 'ic': 0.0, 'da': 0.0, 'stability_penalty': 0.0}
                    _emit(progress_cb, limit, f'{label}: {symbol} — недостаточно истории, использованы равные веса')
                else:
                    weights, evaluation = level_a.optimize(
                        window_frame.reset_index(),
                        config.seed + idx,
                        progress_cb=lambda generation, total, best: _emit(
                            progress_cb,
                            base + (limit - base) * (generation / max(total, 1)),
                            f'{label}: {symbol} — поколение {generation}/{total}, лучший критерий {best:.4f}',
                        ),
                    )
            except Exception as exc:
                weights = np.ones(len(FEATURES), dtype=float) / len(FEATURES)
                evaluation = {'objective': 0.0, 'ic': 0.0, 'da': 0.0, 'stability_penalty': 0.0}
                if log_cb is not None:
                    log_cb(f'Калибровка индикаторов для {symbol} заменена на равные веса из-за ошибки: {exc}', 'WARN')
            a_weights[symbol] = weights
            a_history.append(
                {
                    'date': end_date,
                    'symbol': symbol,
                    'objective': evaluation['objective'],
                    'ic': evaluation['ic'],
                    'da': evaluation['da'],
                    'weights': weights.copy(),
                }
            )
            weight_snapshots[symbol].append(weights.copy())
        if log_cb is not None:
            log_cb(f'{label} завершена', 'READY')

    calibrate_level_a(train_dates[-1], 28, 40, 'Первичная калибровка уровня A')

    cash = float(cost_config.initial_capital)
    quantities = np.zeros(len(symbols), dtype=float)
    average_prices = np.zeros(len(symbols), dtype=float)
    previous_weights = np.zeros(len(symbols), dtype=float)

    equity_dates: list[pd.Timestamp] = [test_dates[0]]
    equity_values: list[float] = [cost_config.initial_capital]
    rebalance_history: list[dict] = []
    cost_history: list[dict] = []

    _emit_snapshot(
        snapshot_cb,
        {
            'mode': 'init',
            'phase': 'Инициализация тестового интервала',
            'symbols': symbols,
            'equity_date': test_dates[0].isoformat(),
            'equity_value': float(cost_config.initial_capital),
            'prices_date': test_dates[0].isoformat(),
            'prices_row': {symbol: float(price_panel.loc[test_dates[0], symbol]) for symbol in symbols},
            'last_weights': np.zeros(len(symbols), dtype=float).tolist(),
            'pareto_front': [],
            'selected_front_index': 0,
            'metrics': _compose_metrics(
                [float(cost_config.initial_capital)],
                rebalance_history,
                cost_history,
                a_history,
                weight_snapshots,
                split_count,
                [test_dates[0]],
            ),
        },
    )

    if tuning.enabled_b:
        if log_cb is not None:
            log_cb('Подбор гиперпараметров уровня B через Optuna', 'INFO')
        try:
            validation_states = _build_validation_states(
                train_dates=train_dates,
                price_panel=price_panel,
                returns=returns,
                symbols=symbols,
                indicator_frames=indicator_frames,
                a_weights=a_weights,
                signal_engine=signal_engine,
                config=config,
            )
            config = LevelBTuner(config, cost_engine).tune_on_validation(
                validation_states=validation_states,
                trials=tuning.trials_b,
                seed=config.seed,
                progress_cb=lambda trial, total, best: _emit(
                    progress_cb,
                    40 + 10 * (trial / max(total, 1)),
                    f'Optuna B: испытание {trial}/{total}, лучший критерий {best:.4f}',
                ),
            )
            if log_cb is not None:
                log_cb('Подбор гиперпараметров уровня B завершён', 'READY')
                log_cb(
                    f'Проверка Q(B): используются Sharpe, MDD, CostRate и Turnover в согласованных долях. Веса λ = ({config.q_b_drawdown_weight:.2f}, {config.q_b_cost_weight:.2f}, {config.q_b_turnover_weight:.2f})',
                    'INFO',
                )
        except Exception as exc:
            if log_cb is not None:
                log_cb(f'Подбор уровня B пропущен из-за ошибки: {exc}', 'WARN')
    else:
        _emit(progress_cb, 50, 'Optuna уровня B пропущен')

    optimizer_b = LevelBOptimizer(config, cost_engine)
    rebalance_points = list(range(0, len(test_dates), config.rebalance_every))
    if rebalance_points[-1] != len(test_dates) - 1:
        rebalance_points.append(len(test_dates) - 1)
    total_rebalances = max(len(rebalance_points) - 1, 1)
    loop_start = 50.0
    loop_span = 47.0

    for point_index, relative_loc in enumerate(rebalance_points[:-1]):
        chunk_start = loop_start + loop_span * (point_index / total_rebalances)
        chunk_end = loop_start + loop_span * ((point_index + 1) / total_rebalances)
        rebalance_date = test_dates[relative_loc]

        if point_index > 0 and config.recalibrate_each_rebalance:
            calibrate_level_a(
                rebalance_date,
                chunk_start,
                chunk_start + 0.28 * (chunk_end - chunk_start),
                f'Перекалибровка уровня A на {rebalance_date.date()}',
            )
            opt_start = chunk_start + 0.28 * (chunk_end - chunk_start)
        else:
            opt_start = chunk_start
            _emit(progress_cb, opt_start, f'Подготовка ребаланса на {rebalance_date.date()}')

        prices_now = price_panel.loc[rebalance_date, symbols].to_numpy(dtype=float)
        equity_pre = cash + float(np.dot(quantities, prices_now))
        state = _state_snapshot(
            date=rebalance_date,
            price_panel=price_panel,
            returns=returns,
            symbols=symbols,
            indicator_frames=indicator_frames,
            a_weights=a_weights,
            signal_engine=signal_engine,
            config=config,
        )
        target_weights, objective_value, diagnostics, pareto_size, pareto_payload = optimizer_b.optimize(
            mu_hat=state['mu_hat'],
            covariance=state['covariance'],
            previous_weights=previous_weights,
            symbols=symbols,
            prices=state['prices'],
            quantities=quantities,
            average_prices=average_prices,
            equity_pre=equity_pre,
            seed=config.seed + point_index * 17,
            progress_cb=lambda generation, total, front: _emit(
                progress_cb,
                opt_start + 0.45 * (chunk_end - chunk_start) * (generation / max(total, 1)),
                f'Оптимизация уровня B на {rebalance_date.date()}: поколение {generation}/{total}, фронт {front}',
            ),
        )
        l1_shift = float(np.sum(np.abs(target_weights - previous_weights)))
        skipped = l1_shift < config.no_trade_band
        if skipped:
            target_weights = previous_weights.copy()
            if log_cb is not None:
                log_cb(
                    f'Ребаланс на {rebalance_date.date()} пропущен: изменение весов {l1_shift:.4f} ниже порога no-trade band {config.no_trade_band:.4f}',
                    'INFO',
                )
        cash, quantities, average_prices, rebalance_costs = cost_engine.apply_rebalance(
            symbols=symbols,
            prices=state['prices'],
            cash=cash,
            quantities=quantities,
            average_prices=average_prices,
            target_weights=target_weights,
            equity_pre=equity_pre,
        )
        period_start_equity = float(cash + np.dot(quantities, state['prices']))
        previous_weights = target_weights.copy()
        rebalance_history.append(
            {
                'date': rebalance_date,
                'weights': target_weights.copy(),
                'objective': objective_value,
                'diagnostics': diagnostics,
                'pareto_size': pareto_size,
                'skipped': skipped,
                'pareto_front': pareto_payload.get('points', []),
                'selected_front_index': pareto_payload.get('selected_index', 0),
                'period_start_equity': period_start_equity,
                'period_end_equity': period_start_equity,
                'period_success': False,
            }
        )
        cost_history.append({'date': rebalance_date, **rebalance_costs})
        if log_cb is not None:
            gross = float(np.sum(np.abs(target_weights)))
            short = float(np.sum(np.clip(-target_weights, 0.0, None)))
            log_cb(
                f'Ребаланс {rebalance_date.date()}: Pareto={pareto_size}, gross={gross:.3f}, short={short:.3f}, turnover={rebalance_costs.get("turnover", 0.0):.3f}',
                'INFO',
            )
        _emit_snapshot(
            snapshot_cb,
            {
                'mode': 'append',
                'phase': f'Ребаланс {rebalance_date.date()}',
                'equity_date': equity_dates[-1].isoformat() if equity_dates else rebalance_date.isoformat(),
                'equity_value': float(equity_values[-1]) if equity_values else float(equity_pre),
                'prices_date': rebalance_date.isoformat(),
                'prices_row': {symbol: float(price_panel.loc[rebalance_date, symbol]) for symbol in symbols},
                'last_weights': target_weights.tolist(),
                'metrics': _compose_metrics(equity_values, rebalance_history, cost_history, a_history, weight_snapshots, split_count, equity_dates),
                'rebalance_date': rebalance_date.isoformat(),
                'pareto_front': pareto_payload.get('points', []),
                'selected_front_index': pareto_payload.get('selected_index', 0),
            },
        )

        next_loc = rebalance_points[point_index + 1]
        holding_dates = test_dates[relative_loc : next_loc + 1]
        holding_count = max(len(holding_dates) - 1, 1)
        hold_start = opt_start + 0.45 * (chunk_end - chunk_start)
        snapshot_stride = max(1, min(4, holding_count // 6 if holding_count > 6 else 1))
        for day_index in range(1, len(holding_dates)):
            current_date = holding_dates[day_index]
            prices_today = price_panel.loc[current_date, symbols].to_numpy(dtype=float)
            holding_costs = cost_engine.holding_costs(symbols, prices_today, quantities, 1.0 / 252.0)
            cash -= sum(holding_costs.values())
            cost_history.append(
                {
                    'date': current_date,
                    'fee': 0.0,
                    'slippage': 0.0,
                    'tax': 0.0,
                    'realized_pnl': 0.0,
                    'turnover': 0.0,
                    **holding_costs,
                }
            )
            equity = cash + float(np.dot(quantities, prices_today))
            equity_dates.append(current_date)
            equity_values.append(equity)
            should_snapshot = day_index == holding_count or day_index == 1 or day_index % snapshot_stride == 0
            if should_snapshot:
                metrics_payload = None
                if day_index == holding_count or day_index % max(1, snapshot_stride * 2) == 0:
                    metrics_payload = _compose_metrics(equity_values, rebalance_history, cost_history, a_history, weight_snapshots, split_count, equity_dates)
                _emit_snapshot(
                    snapshot_cb,
                    {
                        'mode': 'append',
                        'phase': f'Удержание после ребаланса {rebalance_date.date()} — {day_index}/{holding_count}',
                        'equity_date': current_date.isoformat(),
                        'equity_value': float(equity),
                        'prices_date': current_date.isoformat(),
                        'prices_row': {symbol: float(price_panel.loc[current_date, symbol]) for symbol in symbols},
                        'last_weights': target_weights.tolist(),
                        'metrics': metrics_payload,
                    },
                )
            if day_index == holding_count or day_index % max(1, holding_count // 5) == 0:
                _emit(
                    progress_cb,
                    hold_start + (chunk_end - hold_start) * (day_index / holding_count),
                    f'Удержание портфеля после ребаланса {rebalance_date.date()} — {day_index}/{holding_count}',
                )

        if rebalance_history:
            period_end_equity = float(equity_values[-1]) if equity_values else float(period_start_equity)
            rebalance_history[-1]['period_end_equity'] = period_end_equity
            rebalance_history[-1]['period_success'] = period_end_equity > float(rebalance_history[-1].get('period_start_equity', period_start_equity))
            _emit_snapshot(
                snapshot_cb,
                {
                    'mode': 'append',
                    'phase': f'Период после ребаланса {rebalance_date.date()} закрыт',
                    'equity_date': equity_dates[-1].isoformat() if equity_dates else rebalance_date.isoformat(),
                    'equity_value': float(equity_values[-1]) if equity_values else float(period_end_equity),
                    'metrics': _compose_metrics(equity_values, rebalance_history, cost_history, a_history, weight_snapshots, split_count, equity_dates),
                },
            )

    _emit(progress_cb, 98, 'Финальный расчёт метрик и графиков')
    result = _build_result(
        test_dates=equity_dates,
        equity_values=equity_values,
        rebalance_history=rebalance_history,
        cost_history=cost_history,
        a_history=a_history,
        weight_snapshots=weight_snapshots,
        prices_frame=price_panel.loc[test_dates],
        split_count=split_count,
    )
    _emit(progress_cb, 100, 'Бэктест завершён')
    return result



def _state_snapshot(
    date: pd.Timestamp,
    price_panel: pd.DataFrame,
    returns: pd.DataFrame,
    symbols: list[str],
    indicator_frames: dict[str, pd.DataFrame],
    a_weights: dict[str, np.ndarray],
    signal_engine: SignalEngine,
    config: OptimizationConfig,
) -> dict:
    prices = price_panel.loc[date, symbols].to_numpy(dtype=float)
    end_loc = price_panel.index.get_loc(date)
    cov_start = max(1, end_loc - config.cov_window + 1)
    cov_dates = price_panel.index[cov_start : end_loc + 1]
    covariance = shrinkage_covariance(returns.loc[cov_dates[1:]], config.shrink_lambda)
    calib_start = max(1, end_loc - config.calib_window + 1)
    calib_dates = price_panel.index[calib_start : end_loc + 1]
    mu_scale = signal_engine.mu_scale(returns.loc[calib_dates[1:]])
    mu_hat = np.zeros(len(symbols), dtype=float)
    for index, symbol in enumerate(symbols):
        row = indicator_frames[symbol].loc[date]
        score = signal_engine.score_row(row, a_weights[symbol])
        mu_hat[index] = signal_engine.mu_from_score(score, mu_scale)
    return {'prices': prices, 'covariance': covariance, 'mu_hat': mu_hat, 'symbols': symbols}



def _build_level_a_windows(indicator_frames: dict[str, pd.DataFrame], train_dates: pd.Index, calib_window: int) -> dict[str, pd.DataFrame]:
    out = {}
    end_date = train_dates[-1]
    end_loc = train_dates.get_loc(end_date)
    start_loc = max(0, end_loc - calib_window + 1)
    window_dates = train_dates[start_loc : end_loc + 1]
    for symbol, frame in indicator_frames.items():
        out[symbol] = frame.loc[window_dates].dropna(subset=FEATURES + ['Close']).reset_index()
    return out



def _build_validation_states(
    train_dates: pd.Index,
    price_panel: pd.DataFrame,
    returns: pd.DataFrame,
    symbols: list[str],
    indicator_frames: dict[str, pd.DataFrame],
    a_weights: dict[str, np.ndarray],
    signal_engine: SignalEngine,
    config: OptimizationConfig,
) -> list[dict]:
    if len(train_dates) < config.calib_window + config.rebalance_every * 2:
        return []
    tail_len = min(len(train_dates) // 3, max(config.rebalance_every * 4, 120))
    val_dates = train_dates[-tail_len:]
    points = list(range(0, len(val_dates), config.rebalance_every))
    if points[-1] != len(val_dates) - 1:
        points.append(len(val_dates) - 1)
    states: list[dict] = []
    for idx in range(len(points) - 1):
        current_date = val_dates[points[idx]]
        next_date = val_dates[points[idx + 1]]
        state = _state_snapshot(
            date=current_date,
            price_panel=price_panel,
            returns=returns,
            symbols=symbols,
            indicator_frames=indicator_frames,
            a_weights=a_weights,
            signal_engine=signal_engine,
            config=config,
        )
        hold_dates = val_dates[points[idx] : points[idx + 1] + 1]
        hold_returns = []
        for day in hold_dates[1:]:
            prev_day = hold_dates[hold_dates.get_loc(day) - 1]
            ret_vec = price_panel.loc[day, symbols].to_numpy(dtype=float) / price_panel.loc[prev_day, symbols].to_numpy(dtype=float) - 1.0
            hold_returns.append(ret_vec)
        state['holding_returns'] = hold_returns
        state['next_date'] = next_date
        states.append(state)
    return states



def _compose_metrics(
    equity_values: list[float] | np.ndarray,
    rebalance_history: list[dict],
    cost_history: list[dict],
    a_history: list[dict],
    weight_snapshots: dict[str, list[np.ndarray]],
    split_count: int,
    equity_dates: list[pd.Timestamp] | list[str] | None = None,
) -> dict[str, float]:
    equity = np.array(equity_values, dtype=float)
    daily_returns = equity[1:] / np.maximum(equity[:-1], 1e-12) - 1.0 if len(equity) > 1 else np.array([], dtype=float)
    turnover_values = [item.get('diagnostics', {}).get('turnover', 0.0) for item in rebalance_history] if rebalance_history else []
    concentration_values = [item.get('diagnostics', {}).get('concentration', 0.0) for item in rebalance_history] if rebalance_history else []
    short_values = [np.sum(np.clip(-item.get('weights', np.array([])), 0.0, None)) for item in rebalance_history] if rebalance_history else []
    gross_values = [np.sum(np.abs(item.get('weights', np.array([])))) for item in rebalance_history] if rebalance_history else []
    successful_periods = [bool(item.get('period_success')) for item in rebalance_history if item.get('period_start_equity') is not None and item.get('period_end_equity') is not None]
    total_periods = len(successful_periods)
    total_costs = {'fee': 0.0, 'slippage': 0.0, 'tax': 0.0, 'funding': 0.0, 'borrow': 0.0, 'carry': 0.0}
    for row in cost_history:
        for key in total_costs:
            total_costs[key] += float(row.get(key, 0.0))
    total_cost_value = float(sum(total_costs.values()))
    initial_equity = equity[0] if len(equity) else 1.0
    metrics = {
        'Итоговая доходность, %': (equity[-1] / initial_equity - 1.0) * 100.0 if len(equity) else 0.0,
        'CAGR, %': cagr(equity) * 100.0 if len(equity) > 1 else 0.0,
        'Волатильность, % годовых': annualized_volatility(daily_returns) * 100.0 if len(daily_returns) else 0.0,
        'Коэффициент Шарпа': sharpe_ratio(daily_returns) if len(daily_returns) else 0.0,
        'Максимальная просадка, %': max_drawdown(equity) * 100.0 if len(equity) else 0.0,
        'Коэффициент Калмара': calmar_ratio(equity) if len(equity) > 1 else 0.0,
        'Средний оборот': float(np.mean(turnover_values)) if turnover_values else 0.0,
        'Средняя валовая экспозиция': float(np.mean(gross_values)) if gross_values else 0.0,
        'Средняя короткая экспозиция': float(np.mean(short_values)) if short_values else 0.0,
        'Суммарные издержки': total_cost_value,
        'Доля издержек, %': total_cost_value / max(initial_equity, 1e-12) * 100.0,
        'Среднее эффективное число позиций': float(np.mean([1.0 / c for c in concentration_values if c > 1e-12])) if concentration_values else 0.0,
        'Доля удачных периодов, %': (float(np.mean(successful_periods)) * 100.0) if successful_periods else 0.0,
        'Число удачных периодов': float(sum(1 for flag in successful_periods if flag)),
        'Число ребалансировок': float(len(rebalance_history)),
        'Число обнаруженных сплитов': float(split_count),
        'Средний IC уровня A': float(np.mean([item['ic'] for item in a_history])) if a_history else 0.0,
        'Средняя направленная точность уровня A': float(np.mean([item['da'] for item in a_history])) if a_history else 0.0,
        'Средняя устойчивость уровня A': _average_stability(weight_snapshots),
    }
    for key, value in total_costs.items():
        metrics[f'Издержки {key}, % от капитала'] = value / max(initial_equity, 1e-12) * 100.0
    return metrics


def _build_result(
    test_dates: list[pd.Timestamp],
    equity_values: list[float],
    rebalance_history: list[dict],
    cost_history: list[dict],
    a_history: list[dict],
    weight_snapshots: dict[str, list[np.ndarray]],
    prices_frame: pd.DataFrame,
    split_count: int,
) -> BacktestResult:
    metrics = _compose_metrics(equity_values, rebalance_history, cost_history, a_history, weight_snapshots, split_count, test_dates)
    equity = np.array(equity_values, dtype=float)
    return BacktestResult(
        metrics=metrics,
        equity_curve={'dates': [date.isoformat() for date in test_dates], 'values': equity.tolist()},
        prices_frame=prices_frame.copy(),
        rebalance_history=rebalance_history,
        cost_history=cost_history,
        level_a_history=a_history,
    )


def _average_stability(weight_snapshots: dict[str, list[np.ndarray]]) -> float:
    values = []
    for snapshots in weight_snapshots.values():
        if len(snapshots) < 2:
            continue
        diffs = [np.sum(np.abs(snapshots[i] - snapshots[i - 1])) / 2.0 for i in range(1, len(snapshots))]
        values.append(1.0 - float(np.mean(diffs)))
    return float(np.mean(values)) if values else 0.0
