from __future__ import annotations

import numpy as np

from .models import AssetType, CostConfig, RateSet


class CostEngine:
    def __init__(self, config: CostConfig):
        config.ensure_defaults()
        self.config = config

    def asset_type(self, symbol: str) -> AssetType:
        value = self.config.asset_types.get(symbol.upper(), self.config.default_type.value)
        return AssetType(value)

    def rates(self, symbol: str) -> RateSet:
        custom = self.config.asset_rates.get(symbol.upper())
        if custom is not None:
            return custom
        asset_type = self.asset_type(symbol)
        return self.config.default_rates[asset_type.value]

    def apply_rebalance(self, symbols: list[str], prices: np.ndarray, cash: float, quantities: np.ndarray, average_prices: np.ndarray, target_weights: np.ndarray, equity_pre: float) -> tuple[float, np.ndarray, np.ndarray, dict[str, float]]:
        target_notional = target_weights * equity_pre
        target_quantities = np.divide(target_notional, prices, out=np.zeros_like(target_notional), where=np.abs(prices) > 1e-12)
        new_cash = float(cash)
        new_quantities = quantities.copy()
        new_average_prices = average_prices.copy()
        breakdown = {'fee': 0.0, 'slippage': 0.0, 'tax': 0.0, 'funding': 0.0, 'borrow': 0.0, 'carry': 0.0, 'realized_pnl': 0.0, 'turnover': 0.0}
        for index, symbol in enumerate(symbols):
            price = float(prices[index])
            q_old = float(quantities[index])
            q_new = float(target_quantities[index])
            if abs(price) < 1e-12:
                continue
            delta_q = q_new - q_old
            trade_notional = abs(delta_q) * price
            rates = self.rates(symbol)
            fee = rates.fee * trade_notional
            slippage = rates.slippage * trade_notional
            realized_pnl, avg_new = self._realized_pnl_and_avg(q_old, q_new, float(average_prices[index]), price)
            tax = max(realized_pnl, 0.0) * rates.tax
            new_cash -= delta_q * price
            new_cash -= fee + slippage + tax
            new_quantities[index] = q_new
            new_average_prices[index] = avg_new
            breakdown['fee'] += fee
            breakdown['slippage'] += slippage
            breakdown['tax'] += tax
            breakdown['realized_pnl'] += realized_pnl
            breakdown['turnover'] += trade_notional / max(equity_pre, 1e-12)
        return new_cash, new_quantities, new_average_prices, breakdown

    def expected_cost_ratio(self, symbols: list[str], prices: np.ndarray, quantities: np.ndarray, average_prices: np.ndarray, target_weights: np.ndarray, equity_pre: float, horizon_days: int) -> tuple[float, dict[str, float]]:
        temp_cash = equity_pre - float(np.dot(quantities, prices))
        _, target_quantities, _, rebalance_breakdown = self.apply_rebalance(symbols, prices, temp_cash, quantities, average_prices, target_weights, equity_pre)
        holding_breakdown = self.holding_costs(symbols, prices, target_quantities, horizon_days / 252.0)
        breakdown = {
            'fee': rebalance_breakdown['fee'],
            'slippage': rebalance_breakdown['slippage'],
            'tax': rebalance_breakdown['tax'],
            'funding': holding_breakdown['funding'],
            'borrow': holding_breakdown['borrow'],
            'carry': holding_breakdown['carry'],
        }
        total = sum(breakdown.values())
        return total / max(equity_pre, 1e-12), breakdown

    def holding_costs(self, symbols: list[str], prices: np.ndarray, quantities: np.ndarray, dt_years: float) -> dict[str, float]:
        breakdown = {'funding': 0.0, 'borrow': 0.0, 'carry': 0.0}
        for index, symbol in enumerate(symbols):
            price = float(prices[index])
            quantity = float(quantities[index])
            if abs(price) < 1e-12 or abs(quantity) < 1e-12:
                continue
            notional = abs(quantity * price)
            rates = self.rates(symbol)
            asset_type = self.asset_type(symbol)
            if asset_type is AssetType.PERPETUAL:
                breakdown['funding'] += rates.funding * notional * dt_years
            if quantity < 0.0:
                breakdown['borrow'] += rates.borrow * notional * dt_years
            if asset_type in {AssetType.FUTURE, AssetType.PERPETUAL, AssetType.OTHER}:
                breakdown['carry'] += rates.carry * notional * dt_years
        return breakdown

    @staticmethod
    def _realized_pnl_and_avg(q_old: float, q_new: float, avg_old: float, price: float) -> tuple[float, float]:
        eps = 1e-12
        if abs(q_old) < eps:
            if abs(q_new) < eps:
                return 0.0, 0.0
            return 0.0, price
        if abs(q_new) < eps:
            realized = abs(q_old) * (price - avg_old) if q_old > 0 else abs(q_old) * (avg_old - price)
            return realized, 0.0
        if np.sign(q_old) == np.sign(q_new):
            if abs(q_new) > abs(q_old):
                add_qty = abs(q_new) - abs(q_old)
                avg_new = (abs(q_old) * avg_old + add_qty * price) / abs(q_new)
                return 0.0, avg_new
            if abs(q_new) < abs(q_old):
                closed = abs(q_old) - abs(q_new)
                realized = closed * (price - avg_old) if q_old > 0 else closed * (avg_old - price)
                return realized, avg_old
            return 0.0, avg_old
        realized = abs(q_old) * (price - avg_old) if q_old > 0 else abs(q_old) * (avg_old - price)
        return realized, price
