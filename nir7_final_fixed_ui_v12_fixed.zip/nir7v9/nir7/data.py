from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from typing import Callable, Iterable, Optional

import numpy as np
import pandas as pd


HF_CSV_PATH = "hf://datasets/siddharthmb/stocks-ohlcv/ohlcv.csv"
COL_MAP = {
    'date': 'Date',
    'act_symbol': 'Symbol',
    'open': 'Open',
    'high': 'High',
    'low': 'Low',
    'close': 'Close',
    'volume': 'Volume',
}
REQUIRED_COLUMNS = ['Date', 'Symbol', 'Open', 'High', 'Low', 'Close', 'Volume']
COMMON_SPLIT_FACTORS = np.array([
    2.0, 3.0, 4.0, 5.0, 1.5, 4.0 / 3.0, 1.25, 10.0, 20.0,
    0.5, 1.0 / 3.0, 0.25, 0.2, 0.1, 0.05,
], dtype=float)


@dataclass(slots=True)
class SplitEvent:
    symbol: str
    date: pd.Timestamp
    factor: float
    anchor: str
    ratio: float


class DataGateway:
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        self.cache_dir = os.path.join(base_dir, 'cache_hf_ohlcv')
        self.tickers_cache_path = os.path.join(self.cache_dir, 'tickers_cache.json')
        os.makedirs(self.cache_dir, exist_ok=True)

    def ensure_dependencies(self) -> None:
        try:
            import fsspec  # noqa: F401
            import huggingface_hub  # noqa: F401
        except Exception as exc:
            raise RuntimeError('Для чтения данных через hf:// требуются huggingface_hub и fsspec') from exc

    def _ticker_cache_file(self, symbol: str) -> str:
        return os.path.join(self.cache_dir, f'{symbol.upper()}.parquet')

    def load_tickers_cache(self) -> list[str]:
        if os.path.isfile(self.tickers_cache_path):
            try:
                with open(self.tickers_cache_path, 'r', encoding='utf-8') as file:
                    return json.load(file)
            except Exception:
                return []
        return []

    def save_tickers_cache(self, tickers: Iterable[str]) -> None:
        unique = sorted(set(tickers))
        with open(self.tickers_cache_path, 'w', encoding='utf-8') as file:
            json.dump(unique, file, ensure_ascii=False, indent=2)

    def clear_cache(self) -> None:
        if os.path.isfile(self.tickers_cache_path):
            os.remove(self.tickers_cache_path)
        for filename in os.listdir(self.cache_dir):
            if filename.endswith('.parquet'):
                try:
                    os.remove(os.path.join(self.cache_dir, filename))
                except OSError:
                    pass

    def scan_unique_tickers(self, progress_cb: Optional[Callable[[str], None]] = None, max_seconds: int = 45) -> list[str]:
        self.ensure_dependencies()
        tickers: set[str] = set()
        start = time.time()
        iterator = pd.read_csv(HF_CSV_PATH, usecols=['act_symbol'], chunksize=1_000_000)
        scanned = 0
        for chunk in iterator:
            chunk = chunk.dropna()
            tickers.update(chunk['act_symbol'].astype(str).str.upper().unique().tolist())
            scanned += len(chunk)
            if progress_cb is not None:
                progress_cb(f"Просмотрено строк для списка тикеров: {scanned:,}".replace(',', ' '))
            if time.time() - start > max_seconds:
                break
        result = sorted(tickers)
        if result:
            self.save_tickers_cache(result)
        return result

    def load_data_for_pool(self, pool: list[str], use_cache: bool = True, progress_cb: Optional[Callable[[str], None]] = None) -> pd.DataFrame:
        self.ensure_dependencies()
        pool = [item.strip().upper() for item in pool if item.strip()]
        if not pool:
            raise RuntimeError('Пул тикеров пуст')
        cached_frames = []
        missing = []
        if use_cache:
            for symbol in pool:
                path = self._ticker_cache_file(symbol)
                if os.path.isfile(path):
                    try:
                        cached_frames.append(pd.read_parquet(path))
                    except Exception:
                        missing.append(symbol)
                else:
                    missing.append(symbol)
            if cached_frames and not missing:
                data = pd.concat(cached_frames, ignore_index=True)
                return self._normalize_loaded_frame(data)
        per_symbol: dict[str, list[pd.DataFrame]] = {symbol: [] for symbol in pool}
        iterator = pd.read_csv(HF_CSV_PATH, usecols=list(COL_MAP.keys()), chunksize=1_000_000)
        read_total = 0
        kept_total = 0
        for chunk in iterator:
            read_total += len(chunk)
            chunk['act_symbol'] = chunk['act_symbol'].astype(str).str.upper()
            subset = chunk[chunk['act_symbol'].isin(pool)].copy()
            kept_total += len(subset)
            if len(subset):
                subset = subset.rename(columns=COL_MAP)
                subset['Date'] = pd.to_datetime(subset['Date'], errors='coerce')
                for column in ['Open', 'High', 'Low', 'Close', 'Volume']:
                    subset[column] = pd.to_numeric(subset[column], errors='coerce')
                subset = subset.dropna(subset=['Date', 'Close', 'Symbol'])
                subset = subset.sort_values(['Symbol', 'Date'])
                for symbol, frame in subset.groupby('Symbol'):
                    per_symbol[symbol].append(frame)
            if progress_cb is not None:
                progress_cb(f"Прочитано строк: {read_total:,} | оставлено: {kept_total:,}".replace(',', ' '))
        frames = [pd.concat(items, ignore_index=True) for items in per_symbol.values() if items]
        if not frames:
            raise RuntimeError('По выбранным тикерам данные не найдены')
        data = pd.concat(frames, ignore_index=True)
        data = self._normalize_loaded_frame(data)
        self._persist_symbol_cache(data)
        self.save_tickers_cache(data['Symbol'].astype(str).str.upper().unique().tolist())
        return data

    def _persist_symbol_cache(self, frame: pd.DataFrame) -> None:
        for symbol, group in frame.groupby('Symbol'):
            try:
                group.to_parquet(self._ticker_cache_file(symbol), index=False)
            except Exception:
                continue

    def _normalize_loaded_frame(self, frame: pd.DataFrame) -> pd.DataFrame:
        data = frame.copy()
        if set(COL_MAP.keys()).intersection(data.columns):
            data = data.rename(columns=COL_MAP)
        for column in REQUIRED_COLUMNS:
            if column not in data.columns:
                raise RuntimeError(f'Не найдена обязательная колонка: {column}')
        data['Date'] = pd.to_datetime(data['Date'], errors='coerce')
        data['Symbol'] = data['Symbol'].astype(str).str.upper()
        for column in ['Open', 'High', 'Low', 'Close', 'Volume']:
            data[column] = pd.to_numeric(data[column], errors='coerce')
        data = data.dropna(subset=['Date', 'Close', 'Symbol'])
        data = data.drop_duplicates(subset=['Date', 'Symbol'])
        data = data.sort_values(['Symbol', 'Date']).reset_index(drop=True)
        return data


def strict_intersection_panel(frame: pd.DataFrame, price_column: str = 'Close') -> pd.DataFrame:
    panel = frame.pivot_table(index='Date', columns='Symbol', values=price_column, aggfunc='last').sort_index()
    panel = panel.dropna(axis=0, how='any')
    if len(panel) < 120:
        raise RuntimeError('После приведения к общему календарю осталось недостаточно наблюдений')
    return panel


def detect_and_adjust_splits(frame: pd.DataFrame) -> tuple[pd.DataFrame, list[SplitEvent]]:
    adjusted_groups: list[pd.DataFrame] = []
    events: list[SplitEvent] = []
    for symbol, group in frame.groupby('Symbol', sort=False):
        adj_group, adj_events = _adjust_symbol_group(symbol, group.sort_values('Date').reset_index(drop=True))
        adjusted_groups.append(adj_group)
        events.extend(adj_events)
    adjusted = pd.concat(adjusted_groups, ignore_index=True)
    adjusted = adjusted.sort_values(['Symbol', 'Date']).reset_index(drop=True)
    return adjusted, events


def _adjust_symbol_group(symbol: str, group: pd.DataFrame) -> tuple[pd.DataFrame, list[SplitEvent]]:
    data = group.copy().reset_index(drop=True)
    n_rows = len(data)
    if n_rows < 2:
        data['SplitFactor'] = 1.0
        return data, []
    split_factor = np.ones(n_rows, dtype=float)
    events: list[SplitEvent] = []
    prev_close = data['Close'].shift(1).to_numpy(dtype=float)
    open_price = data['Open'].to_numpy(dtype=float)
    close_price = data['Close'].to_numpy(dtype=float)
    for idx in range(1, n_rows):
        candidates: list[tuple[str, float]] = []
        if open_price[idx] > 1e-12 and prev_close[idx] > 1e-12:
            candidates.append(('open', prev_close[idx] / open_price[idx]))
        if close_price[idx] > 1e-12 and prev_close[idx] > 1e-12:
            candidates.append(('close', prev_close[idx] / close_price[idx]))
        if not candidates:
            continue
        event = _match_split_candidate(symbol, pd.Timestamp(data.loc[idx, 'Date']), candidates)
        if event is None:
            continue
        split_factor[idx] = event.factor
        events.append(event)
    cumulative = 1.0
    price_factor = np.ones(n_rows, dtype=float)
    volume_factor = np.ones(n_rows, dtype=float)
    for idx in range(n_rows - 1, -1, -1):
        price_factor[idx] = cumulative
        volume_factor[idx] = 1.0 / cumulative
        if idx > 0:
            cumulative *= split_factor[idx]
    for column in ['Open', 'High', 'Low', 'Close']:
        data[column] = data[column].to_numpy(dtype=float) / price_factor
    data['Volume'] = data['Volume'].to_numpy(dtype=float) / volume_factor
    data['SplitFactor'] = split_factor
    return data, events


def _match_split_candidate(symbol: str, date: pd.Timestamp, candidates: list[tuple[str, float]]) -> Optional[SplitEvent]:
    best_event: Optional[SplitEvent] = None
    best_distance = float('inf')
    for anchor, ratio in candidates:
        if ratio <= 0.0 or not np.isfinite(ratio):
            continue
        nearest = float(COMMON_SPLIT_FACTORS[np.argmin(np.abs(COMMON_SPLIT_FACTORS - ratio))])
        relative_error = abs(ratio - nearest) / max(abs(nearest), 1e-12)
        magnitude = max(ratio, 1.0 / max(ratio, 1e-12))
        if magnitude < 1.45:
            continue
        if relative_error > 0.12:
            continue
        if relative_error < best_distance:
            best_distance = relative_error
            best_event = SplitEvent(symbol=symbol, date=date, factor=nearest, anchor=anchor, ratio=float(ratio))
    return best_event
