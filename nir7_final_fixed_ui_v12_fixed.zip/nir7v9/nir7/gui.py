from __future__ import annotations

import json
import queue
import threading
import time
import traceback
from dataclasses import asdict
from pathlib import Path

import matplotlib
matplotlib.use('TkAgg')

import numpy as np
import pandas as pd
import seaborn as sns
import tkinter as tk
import ttkbootstrap as ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter
from matplotlib import dates as mdates
from tkinter import messagebox
from tkinter import font as tkfont
from ttkbootstrap import Style

from .backtest import run_backtest
from .data import DataGateway
from .models import AssetType, CostConfig, OptimizationConfig, RateSet, TuningConfig
from .utils import parse_rate_mapping, parse_symbol_mapping

sns.set_theme(style='whitegrid', context='notebook', palette='deep')


class ScrollableFrame(ttk.Frame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.canvas = tk.Canvas(self, highlightthickness=0, borderwidth=0)
        self.scrollbar = ttk.Scrollbar(self, orient='vertical', command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.grid(row=0, column=0, sticky='nsew')
        self.scrollbar.grid(row=0, column=1, sticky='ns')
        self.inner = ttk.Frame(self.canvas)
        self.window_id = self.canvas.create_window((0, 0), window=self.inner, anchor='nw')
        self.inner.bind('<Configure>', self._on_inner_configure)
        self.canvas.bind('<Configure>', self._on_canvas_configure)
        self.inner.bind('<Enter>', self._bind_mousewheel)
        self.inner.bind('<Leave>', self._unbind_mousewheel)

    def _on_inner_configure(self, _event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox('all'))

    def _on_canvas_configure(self, event):
        self.canvas.itemconfigure(self.window_id, width=event.width)

    def _bind_mousewheel(self, _event=None):
        self.canvas.bind_all('<MouseWheel>', self._on_mousewheel)
        self.canvas.bind_all('<Button-4>', self._on_mousewheel_linux)
        self.canvas.bind_all('<Button-5>', self._on_mousewheel_linux)

    def _unbind_mousewheel(self, _event=None):
        self.canvas.unbind_all('<MouseWheel>')
        self.canvas.unbind_all('<Button-4>')
        self.canvas.unbind_all('<Button-5>')

    def _on_mousewheel(self, event):
        delta = -1 if event.delta > 0 else 1
        self.canvas.yview_scroll(delta, 'units')

    def _on_mousewheel_linux(self, event):
        delta = -1 if event.num == 4 else 1
        self.canvas.yview_scroll(delta, 'units')


class SparklineCanvas(tk.Canvas):
    def __init__(self, master, width=220, height=56, bg='#ffffff'):
        super().__init__(master, width=width, height=height, bg=bg, highlightthickness=0)
        self.base_width = width
        self.base_height = height

    def draw_series(self, values: list[float], line='#0b63ce', fill='#dfefff', show_zero=False):
        self.delete('all')
        width = max(10, int(self.winfo_width() or self.base_width))
        height = max(10, int(self.winfo_height() or self.base_height))
        if not values:
            self.create_text(width / 2, height / 2, text='нет данных', fill='#888888', font=('Segoe UI', 9))
            return
        arr = np.asarray(values, dtype=float)
        if len(arr) == 1:
            y = height / 2
            self.create_line(6, y, width - 6, y, fill=line, width=2)
            return
        vmin = float(np.min(arr))
        vmax = float(np.max(arr))
        if abs(vmax - vmin) < 1e-12:
            vmax = vmin + 1e-12
        x = np.linspace(6, width - 6, len(arr))
        y = 6 + (height - 12) * (1 - (arr - vmin) / (vmax - vmin))
        if show_zero and vmin < 0 < vmax:
            zero_y = 6 + (height - 12) * (1 - (0 - vmin) / (vmax - vmin))
            self.create_line(4, zero_y, width - 4, zero_y, fill='#dddddd', dash=(2, 2))
        coords = []
        for xv, yv in zip(x, y):
            coords.extend((float(xv), float(yv)))
        fill_coords = [x[0], height - 4, *coords, x[-1], height - 4]
        self.create_polygon(*fill_coords, fill=fill, outline='')
        self.create_line(*coords, fill=line, width=2, smooth=True)
        self.create_text(width - 8, y[-1], text=f'{arr[-1]:.3f}', anchor='e', fill='#444444', font=('Segoe UI', 8, 'bold'))


class MetricCard(ttk.Frame):
    def __init__(self, master, metric_key: str, on_toggle):
        super().__init__(master, padding=(10, 8), bootstyle='light')
        self.metric_key = metric_key
        self.on_toggle = on_toggle
        self.columnconfigure(1, weight=1)
        self.title_label = ttk.Label(self, text=metric_key, font=('Segoe UI', 12, 'bold'))
        self.title_label.grid(row=0, column=0, sticky='w')
        self.value_label = ttk.Label(self, text='—', font=('Segoe UI', 15))
        self.value_label.grid(row=1, column=0, sticky='w', pady=(4, 0))
        self.sparkline = SparklineCanvas(self, width=280, height=56)
        self.sparkline.grid(row=0, column=1, rowspan=2, sticky='we', padx=(12, 12))
        self.toggle_button = ttk.Button(self, text='Добавить в дашборд', command=self._toggle, width=20)
        self.toggle_button.grid(row=0, column=2, rowspan=2, sticky='e')
        ttk.Separator(self, orient='horizontal').grid(row=2, column=0, columnspan=3, sticky='we', pady=(8, 0))

    def _toggle(self):
        self.on_toggle(self.metric_key)

    def update_card(self, value, history: list[float], in_dashboard: bool):
        if isinstance(value, float):
            self.value_label.configure(text=f'{value:.6f}')
        else:
            self.value_label.configure(text=str(value))
        self.toggle_button.configure(text='Убрать из дашборда' if in_dashboard else 'Добавить в дашборд')
        if isinstance(value, (float, int)):
            self.sparkline.draw_series(history, line='#0b63ce', fill='#e7f0ff', show_zero=True)
        else:
            self.sparkline.draw_series([], line='#0b63ce', fill='#e7f0ff')


class DashboardMetricPanel(ttk.Frame):
    def __init__(self, master, metric_key: str, on_remove):
        super().__init__(master, padding=(8, 8), bootstyle='light')
        self.metric_key = metric_key
        self.on_remove = on_remove
        self.columnconfigure(0, weight=1)
        head = ttk.Frame(self)
        head.grid(row=0, column=0, sticky='we')
        head.columnconfigure(0, weight=1)
        self.title_label = ttk.Label(head, text=metric_key, font=('Segoe UI', 11, 'bold'))
        self.title_label.grid(row=0, column=0, sticky='w')
        ttk.Button(head, text='Убрать', command=lambda: self.on_remove(self.metric_key), width=10).grid(row=0, column=1, sticky='e')
        self.value_label = ttk.Label(self, text='—', font=('Segoe UI', 13))
        self.value_label.grid(row=1, column=0, sticky='w', pady=(2, 4))
        self.sparkline = SparklineCanvas(self, width=420, height=96)
        self.sparkline.grid(row=2, column=0, sticky='we')

    def update_panel(self, value, history: list[float]):
        if isinstance(value, float):
            self.value_label.configure(text=f'{value:.6f}')
        else:
            self.value_label.configure(text=str(value))
        self.sparkline.draw_series(history, line='#8e24aa', fill='#f2e6f8', show_zero=True)


class Application(tk.Tk):
    def __init__(self, base_dir: str | None = None):
        super().__init__()
        Style(theme='flatly')
        self.title('NIR7 — система ребалансировки портфеля')
        self.geometry('1880x1080')
        self.minsize(1460, 900)
        self.base_dir = base_dir or str(Path(__file__).resolve().parent.parent)
        self.gateway = DataGateway(self.base_dir)
        self.queue: queue.Queue = queue.Queue()
        self.is_running = False
        self.is_scanning = False
        self.log_records: list[str] = []
        self.last_run_context: dict = {}
        self.tickers_cache = self.gateway.load_tickers_cache()
        self._ticker_search_after_id = None
        self._last_live_render_ts = 0.0
        self._pending_snapshot: dict | None = None
        self.live_state: dict = {}
        self.metric_cards: dict[str, MetricCard] = {}
        self.dashboard_metric_panels: dict[str, DashboardMetricPanel] = {}
        self.selected_dashboard_metrics: list[str] = [
            'Итоговая доходность, %',
            'Коэффициент Шарпа',
            'Максимальная просадка, %',
            'Доля издержек, %',
        ]
        self.show_trend_line_var = tk.BooleanVar(value=True)
        self.show_period_outcomes_var = tk.BooleanVar(value=False)
        self.show_rebalance_lines_var = tk.BooleanVar(value=True)
        self.main_metric_order = [
            'Статус расчёта',
            'Итоговая доходность, %',
            'CAGR, %',
            'Волатильность, % годовых',
            'Коэффициент Шарпа',
            'Максимальная просадка, %',
            'Коэффициент Калмара',
            'Средний оборот',
            'Средняя валовая экспозиция',
            'Средняя короткая экспозиция',
            'Суммарные издержки',
            'Доля издержек, %',
            'Среднее эффективное число позиций',
            'Доля удачных периодов, %',
            'Число удачных периодов',
            'Число ребалансировок',
            'Средний IC уровня A',
            'Средняя направленная точность уровня A',
            'Средняя устойчивость уровня A',
            'Издержки fee, % от капитала',
            'Издержки slippage, % от капитала',
            'Издержки tax, % от капитала',
            'Издержки funding, % от капитала',
            'Издержки borrow, % от капитала',
            'Издержки carry, % от капитала',
            'Число обнаруженных сплитов',
        ]
        self.log_font = tkfont.Font(family='Consolas', size=10)
        self._build_ui()
        self.after(140, self._poll_queue)
        if self.tickers_cache:
            self._log(f'Из локального кэша загружено тикеров: {len(self.tickers_cache)}', 'READY')

    def _build_ui(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        sidebar = ttk.Frame(self, padding=10)
        sidebar.grid(row=0, column=0, sticky='nsew')
        sidebar.columnconfigure(0, weight=1)
        sidebar.rowconfigure(1, weight=1)
        sidebar.rowconfigure(2, weight=0)
        sidebar.configure(width=540)

        top = ttk.LabelFrame(sidebar, text='Пул тикеров')
        top.grid(row=0, column=0, sticky='new', pady=(0, 8))
        top.columnconfigure(0, weight=1)
        self.tickers_var = tk.StringVar(value='AAPL, MSFT, AMZN, TSLA, NVDA')
        self.tickers_entry = ttk.Entry(top, textvariable=self.tickers_var)
        self.tickers_entry.grid(row=0, column=0, columnspan=2, sticky='we', pady=(0, 6), padx=6)
        self.suggestion_popup = ttk.Frame(top)
        self.suggestion_popup.grid(row=1, column=0, columnspan=2, sticky='we', padx=6)
        self.suggestion_popup.columnconfigure(0, weight=1)
        self.suggestion_listbox = tk.Listbox(self.suggestion_popup, height=6, activestyle='dotbox', exportselection=False)
        self.suggestion_listbox.grid(row=0, column=0, sticky='we')
        suggestion_scroll = ttk.Scrollbar(self.suggestion_popup, orient='vertical', command=self.suggestion_listbox.yview)
        suggestion_scroll.grid(row=0, column=1, sticky='ns')
        self.suggestion_listbox.configure(yscrollcommand=suggestion_scroll.set)
        self.suggestion_listbox.bind('<<ListboxSelect>>', self._pick_suggestion)
        self.suggestion_listbox.bind('<ButtonRelease-1>', self._pick_suggestion)
        self.suggestion_listbox.bind('<Return>', self._pick_suggestion)
        self.suggestion_listbox.bind('<Escape>', lambda _e: self._hide_suggestions())
        self.suggestion_listbox.bind('<FocusOut>', self._schedule_hide_suggestions)
        self.suggestion_popup.grid_remove()
        self.tickers_entry.bind('<KeyRelease>', self._on_ticker_typing)
        self.tickers_entry.bind('<FocusIn>', self._on_ticker_typing)
        self.tickers_entry.bind('<FocusOut>', self._schedule_hide_suggestions)
        self.tickers_entry.bind('<Down>', self._focus_suggestion_listbox)
        self.scan_button = ttk.Button(top, text='Сканировать тикеры', command=self._scan_tickers)
        self.scan_button.grid(row=2, column=0, sticky='we', pady=(6, 0), padx=(6, 3))
        ttk.Button(top, text='Очистить кэш', command=self._clear_cache).grid(row=2, column=1, sticky='we', padx=(3, 6), pady=(6, 0))

        middle = ScrollableFrame(sidebar)
        middle.grid(row=1, column=0, sticky='nsew')
        content = middle.inner
        content.columnconfigure(0, weight=1)

        costs_block = ttk.LabelFrame(content, text='Типы активов и издержки')
        costs_block.grid(row=0, column=0, sticky='we', pady=(0, 8))
        costs_block.columnconfigure(1, weight=1)
        self.default_type_var = tk.StringVar(value=AssetType.EQUITY.value)
        ttk.Label(costs_block, text='Тип по умолчанию').grid(row=0, column=0, sticky='w', pady=2, padx=6)
        ttk.Combobox(costs_block, textvariable=self.default_type_var, values=[item.value for item in AssetType], state='readonly').grid(row=0, column=1, sticky='we', pady=2, padx=6)
        self.initial_capital_var = tk.StringVar(value='1000000')
        ttk.Label(costs_block, text='Начальный капитал').grid(row=1, column=0, sticky='w', pady=2, padx=6)
        ttk.Entry(costs_block, textvariable=self.initial_capital_var).grid(row=1, column=1, sticky='we', pady=2, padx=6)
        self.fee_var = tk.StringVar(value='0.001')
        self.slippage_var = tk.StringVar(value='0.0005')
        self.tax_var = tk.StringVar(value='0.0')
        self.funding_var = tk.StringVar(value='0.0')
        self.borrow_var = tk.StringVar(value='0.0')
        self.carry_var = tk.StringVar(value='0.0')
        cost_rows = [
            ('Комиссия', self.fee_var),
            ('Проскальзывание', self.slippage_var),
            ('Налог', self.tax_var),
            ('Фандинг', self.funding_var),
            ('Стоимость шорта', self.borrow_var),
            ('Керри', self.carry_var),
        ]
        for index, (title, variable) in enumerate(cost_rows, start=2):
            ttk.Label(costs_block, text=title).grid(row=index, column=0, sticky='w', pady=2, padx=6)
            ttk.Entry(costs_block, textvariable=variable).grid(row=index, column=1, sticky='we', pady=2, padx=6)
        ttk.Label(costs_block, text='Переопределение типов: TICKER=тип', font=('Segoe UI', 9)).grid(row=8, column=0, columnspan=2, sticky='w', pady=(8, 2), padx=6)
        self.asset_type_text = tk.Text(costs_block, height=4)
        self.asset_type_text.grid(row=9, column=0, columnspan=2, sticky='we', padx=6)
        ttk.Label(costs_block, text='Переопределение ставок: TICKER: fee=..., tax=...', font=('Segoe UI', 9)).grid(row=10, column=0, columnspan=2, sticky='w', pady=(8, 2), padx=6)
        self.asset_rate_text = tk.Text(costs_block, height=5)
        self.asset_rate_text.grid(row=11, column=0, columnspan=2, sticky='we', padx=6)

        params_block = ttk.LabelFrame(content, text='Параметры модели')
        params_block.grid(row=1, column=0, sticky='we', pady=(0, 8))
        params_block.columnconfigure(1, weight=1)
        self.calib_var = tk.StringVar(value='500')
        self.cov_var = tk.StringVar(value='500')
        self.z_var = tk.StringVar(value='60')
        self.horizon_var = tk.StringVar(value='30')
        self.rebalance_var = tk.StringVar(value='30')
        self.wmin_var = tk.StringVar(value='-0.20')
        self.wmax_var = tk.StringVar(value='0.20')
        self.leverage_var = tk.StringVar(value='0.80')
        self.max_assets_var = tk.StringVar(value='10')
        self.a_max_var = tk.StringVar(value='0.30')
        self.shrink_var = tk.StringVar(value='0.50')
        self.mu_min_var = tk.StringVar(value='0.006')
        self.alpha_rank_var = tk.StringVar(value='0.6')
        self.beta_reg_var = tk.StringVar(value='0.18')
        self.eta_var = tk.StringVar(value='0.30')
        self.scalar_rho_var = tk.StringVar(value='0.05')
        self.scalar_weights_var = tk.StringVar(value='1.15, 1.25, 1.35, 1.10')
        self.no_trade_band_var = tk.StringVar(value='0.08')
        rows = [
            ('Окно калибровки', self.calib_var),
            ('Окно риска', self.cov_var),
            ('Окно z-нормализации', self.z_var),
            ('Горизонт прогноза', self.horizon_var),
            ('Частота ребалансировки', self.rebalance_var),
            ('Минимальный вес', self.wmin_var),
            ('Максимальный вес', self.wmax_var),
            ('Лимит валовой экспозиции', self.leverage_var),
            ('Максимум активов', self.max_assets_var),
            ('Ограничение |a_k|', self.a_max_var),
            ('Параметр стягивания', self.shrink_var),
            ('Нижний порог μscale', self.mu_min_var),
            ('Вес рангового критерия', self.alpha_rank_var),
            ('Регуляризация β', self.beta_reg_var),
            ('Штраф нестабильности η', self.eta_var),
            ('Параметр ρ', self.scalar_rho_var),
            ('Порог no-trade band', self.no_trade_band_var),
            ('Веса критериев γ', self.scalar_weights_var),
        ]
        for index, (title, variable) in enumerate(rows):
            ttk.Label(params_block, text=title).grid(row=index, column=0, sticky='w', pady=2, padx=6)
            ttk.Entry(params_block, textvariable=variable).grid(row=index, column=1, sticky='we', pady=2, padx=6)

        tune_block = ttk.LabelFrame(content, text='Подбор гиперпараметров')
        tune_block.grid(row=2, column=0, sticky='we', pady=(0, 8))
        tune_block.columnconfigure(1, weight=1)
        self.optuna_a_var = tk.BooleanVar(value=True)
        self.optuna_b_var = tk.BooleanVar(value=True)
        self.trials_a_var = tk.StringVar(value='12')
        self.trials_b_var = tk.StringVar(value='10')
        self.recalibrate_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(tune_block, text='Optuna для уровня A', variable=self.optuna_a_var).grid(row=0, column=0, columnspan=2, sticky='w', padx=6)
        ttk.Label(tune_block, text='Испытаний A').grid(row=1, column=0, sticky='w', pady=2, padx=6)
        ttk.Entry(tune_block, textvariable=self.trials_a_var).grid(row=1, column=1, sticky='we', pady=2, padx=6)
        ttk.Checkbutton(tune_block, text='Optuna для уровня B', variable=self.optuna_b_var).grid(row=2, column=0, columnspan=2, sticky='w', padx=6)
        ttk.Label(tune_block, text='Испытаний B').grid(row=3, column=0, sticky='w', pady=2, padx=6)
        ttk.Entry(tune_block, textvariable=self.trials_b_var).grid(row=3, column=1, sticky='we', pady=2, padx=6)
        ttk.Checkbutton(tune_block, text='Перекалибровка уровня A на каждом ребалансе', variable=self.recalibrate_var).grid(row=4, column=0, columnspan=2, sticky='w', pady=(6, 2), padx=6)

        bottom = ttk.LabelFrame(sidebar, text='Управление и журнал')
        bottom.grid(row=2, column=0, sticky='nsew', pady=(8, 0))
        bottom.columnconfigure(0, weight=1)
        self.run_button = ttk.Button(bottom, text='Запуск расчёта', command=self._run_thread)
        self.run_button.grid(row=0, column=0, sticky='we', padx=6, pady=(4, 0))
        ttk.Label(bottom, text='Прогресс', font=('Segoe UI', 11, 'bold')).grid(row=1, column=0, sticky='w', pady=(10, 0), padx=6)
        self.progress_label = ttk.Label(bottom, text='Ожидание запуска')
        self.progress_label.grid(row=2, column=0, sticky='we', padx=6)
        self.progress = ttk.Progressbar(bottom, maximum=100, mode='determinate')
        self.progress.grid(row=3, column=0, sticky='we', pady=(4, 8), padx=6)
        ttk.Label(bottom, text='Журнал', font=('Segoe UI', 11, 'bold')).grid(row=4, column=0, sticky='w', padx=6)
        log_frame = ttk.Frame(bottom)
        log_frame.grid(row=5, column=0, sticky='nsew', padx=6, pady=(0, 6))
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.log_widget = tk.Text(log_frame, height=12, state='disabled', wrap='word', font=self.log_font)
        self.log_widget.grid(row=0, column=0, sticky='nsew')
        log_scroll = ttk.Scrollbar(log_frame, orient='vertical', command=self.log_widget.yview)
        log_scroll.grid(row=0, column=1, sticky='ns')
        self.log_widget.configure(yscrollcommand=log_scroll.set)
        for tag, color in [('INFO', '#555555'), ('READY', '#1b7f3b'), ('WARN', '#b56a00'), ('ERROR', '#c62828')]:
            self.log_widget.tag_configure(tag, foreground=color)

        self.notebook = ttk.Notebook(self)
        self.notebook.grid(row=0, column=1, sticky='nsew', padx=10, pady=10)
        self.metrics_tab = ttk.Frame(self.notebook)
        self.equity_tab = ttk.Frame(self.notebook)
        self.prices_tab = ttk.Frame(self.notebook)
        self.alloc_tab = ttk.Frame(self.notebook)
        self.dashboard_tab = ttk.Frame(self.notebook)
        self.pareto_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.metrics_tab, text='Метрики')
        self.notebook.add(self.equity_tab, text='Капитал')
        self.notebook.add(self.prices_tab, text='Цены')
        self.notebook.add(self.alloc_tab, text='Структура портфеля')
        self.notebook.add(self.dashboard_tab, text='Дашборд')
        self.notebook.add(self.pareto_tab, text='Фронты Парето')

        self._build_metrics_tab()
        self._build_plot_tabs()
        self._build_dashboard_tab()
        self._build_pareto_tab()

    def _build_metrics_tab(self):
        self.metrics_tab.columnconfigure(0, weight=1)
        self.metrics_tab.rowconfigure(0, weight=1)
        self.metrics_scroll = ScrollableFrame(self.metrics_tab)
        self.metrics_scroll.grid(row=0, column=0, sticky='nsew', padx=8, pady=8)
        self.metrics_scroll.inner.columnconfigure(0, weight=1)

    def _build_plot_tabs(self):
        equity_controls = ttk.Frame(self.equity_tab, padding=(8, 8, 8, 0))
        equity_controls.pack(fill='x')
        ttk.Checkbutton(
            equity_controls,
            text='Нарисовать линию тренда',
            variable=self.show_trend_line_var,
            command=self._rerender_equity_views,
            bootstyle='round-toggle',
        ).pack(side='left', padx=(0, 10))
        ttk.Checkbutton(
            equity_controls,
            text='Красить периоды между ребалансами',
            variable=self.show_period_outcomes_var,
            command=self._rerender_equity_views,
            bootstyle='round-toggle',
        ).pack(side='left', padx=(0, 10))
        ttk.Checkbutton(
            equity_controls,
            text='Показывать линии ребалансировок',
            variable=self.show_rebalance_lines_var,
            command=self._rerender_equity_views,
            bootstyle='round-toggle',
        ).pack(side='left')

        equity_chart = ttk.Frame(self.equity_tab)
        equity_chart.pack(fill='both', expand=True)
        self.equity_fig = Figure(figsize=(10, 6), dpi=100)
        self.equity_ax = self.equity_fig.add_subplot(111)
        self.equity_canvas = FigureCanvasTkAgg(self.equity_fig, master=equity_chart)
        self.equity_canvas.get_tk_widget().pack(fill='both', expand=True)
        NavigationToolbar2Tk(self.equity_canvas, equity_chart, pack_toolbar=False).pack(fill='x')

        self.prices_fig = Figure(figsize=(10, 6), dpi=100)
        self.prices_ax = self.prices_fig.add_subplot(111)
        self.prices_canvas = FigureCanvasTkAgg(self.prices_fig, master=self.prices_tab)
        self.prices_canvas.get_tk_widget().pack(fill='both', expand=True)
        NavigationToolbar2Tk(self.prices_canvas, self.prices_tab, pack_toolbar=False).pack(fill='x')

        self.alloc_fig = Figure(figsize=(10, 6), dpi=100)
        self.alloc_ax = self.alloc_fig.add_subplot(111)
        self.alloc_canvas = FigureCanvasTkAgg(self.alloc_fig, master=self.alloc_tab)
        self.alloc_canvas.get_tk_widget().pack(fill='both', expand=True)
        NavigationToolbar2Tk(self.alloc_canvas, self.alloc_tab, pack_toolbar=False).pack(fill='x')

    def _build_dashboard_tab(self):
        self.dashboard_tab.columnconfigure(0, weight=1)
        self.dashboard_tab.rowconfigure(0, weight=3)
        self.dashboard_tab.rowconfigure(1, weight=2)

        charts = ttk.Frame(self.dashboard_tab, padding=(8, 8, 8, 4))
        charts.grid(row=0, column=0, sticky='nsew')
        for col in range(3):
            charts.columnconfigure(col, weight=1)
        charts.rowconfigure(0, weight=1)

        self.dashboard_equity_fig = Figure(figsize=(4.8, 3.4), dpi=100)
        self.dashboard_equity_ax = self.dashboard_equity_fig.add_subplot(111)
        self.dashboard_equity_canvas = FigureCanvasTkAgg(self.dashboard_equity_fig, master=charts)
        self.dashboard_equity_canvas.get_tk_widget().grid(row=0, column=0, sticky='nsew', padx=(0, 4))

        self.dashboard_prices_fig = Figure(figsize=(4.8, 3.4), dpi=100)
        self.dashboard_prices_ax = self.dashboard_prices_fig.add_subplot(111)
        self.dashboard_prices_canvas = FigureCanvasTkAgg(self.dashboard_prices_fig, master=charts)
        self.dashboard_prices_canvas.get_tk_widget().grid(row=0, column=1, sticky='nsew', padx=4)

        self.dashboard_alloc_fig = Figure(figsize=(4.8, 3.4), dpi=100)
        self.dashboard_alloc_ax = self.dashboard_alloc_fig.add_subplot(111)
        self.dashboard_alloc_canvas = FigureCanvasTkAgg(self.dashboard_alloc_fig, master=charts)
        self.dashboard_alloc_canvas.get_tk_widget().grid(row=0, column=2, sticky='nsew', padx=(4, 0))

        self.dashboard_metrics_scroll = ScrollableFrame(self.dashboard_tab)
        self.dashboard_metrics_scroll.grid(row=1, column=0, sticky='nsew', padx=8, pady=(4, 8))
        self.dashboard_metrics_scroll.inner.columnconfigure(0, weight=1)
        self.dashboard_metrics_scroll.inner.columnconfigure(1, weight=1)

    def _build_pareto_tab(self):
        self.pareto_tab.columnconfigure(0, weight=1)
        self.pareto_tab.rowconfigure(0, weight=1)
        self.pareto_tab.rowconfigure(1, weight=0)
        self.pareto_fig = Figure(figsize=(11, 7), dpi=100)
        self.pareto_ax = self.pareto_fig.add_subplot(111, projection='3d')
        self.pareto_canvas = FigureCanvasTkAgg(self.pareto_fig, master=self.pareto_tab)
        self.pareto_canvas.get_tk_widget().grid(row=0, column=0, sticky='nsew')
        NavigationToolbar2Tk(self.pareto_canvas, self.pareto_tab, pack_toolbar=False).grid(row=1, column=0, sticky='we')
        self.pareto_info = ttk.Label(self.pareto_tab, text='Пока фронт Парето не построен', anchor='w', justify='left')
        self.pareto_info.grid(row=2, column=0, sticky='we', padx=10, pady=(0, 10))

    def _scan_tickers(self):
        if self.is_scanning or self.is_running:
            return
        self.is_scanning = True
        self.scan_button.configure(state='disabled')
        self.queue.put({'kind': 'progress', 'p': 0, 'text': 'Сканирование списка тикеров...'})
        self.queue.put({'kind': 'log', 'msg': 'Запущено сканирование списка доступных тикеров', 'level': 'INFO'})

        def worker():
            try:
                scan_tick = {'value': 0}

                def on_scan_progress(text: str):
                    scan_tick['value'] = min(95, scan_tick['value'] + 2)
                    self.queue.put({'kind': 'progress', 'p': scan_tick['value'], 'text': text})

                tickers = self.gateway.scan_unique_tickers(on_scan_progress)
                self.tickers_cache = tickers
                self.queue.put({'kind': 'scan_done', 'count': len(tickers)})
            except Exception as exc:
                self.queue.put({'kind': 'scan_error', 'msg': str(exc), 'trace': traceback.format_exc()})

        threading.Thread(target=worker, daemon=True).start()

    def _clear_cache(self):
        try:
            self.gateway.clear_cache()
            self.tickers_cache = []
            self._log('Локальный кэш очищен', 'READY')
            self._hide_suggestions()
        except Exception as exc:
            self._log(str(exc), 'ERROR')

    def _schedule_hide_suggestions(self, _event=None):
        self.after(180, self._hide_suggestions)

    def _focus_suggestion_listbox(self, _event=None):
        if not self.suggestion_popup.winfo_ismapped() or self.suggestion_listbox.size() == 0:
            return
        self.suggestion_listbox.focus_set()
        self.suggestion_listbox.selection_clear(0, 'end')
        self.suggestion_listbox.selection_set(0)
        self.suggestion_listbox.activate(0)

    def _on_ticker_typing(self, _event=None):
        if self._ticker_search_after_id is not None:
            self.after_cancel(self._ticker_search_after_id)
        self._ticker_search_after_id = self.after(140, self._refresh_suggestions)

    def _refresh_suggestions(self):
        self._ticker_search_after_id = None
        if not self.tickers_cache:
            self._hide_suggestions()
            return
        raw = self.tickers_var.get()
        current = raw.split(',')[-1].strip().upper()
        if not current:
            self._hide_suggestions()
            return
        starts = [item for item in self.tickers_cache if item.startswith(current)]
        contains = [item for item in self.tickers_cache if current in item and not item.startswith(current)]
        matches = (starts + contains)[:20]
        if not matches:
            self._hide_suggestions()
            return
        self.suggestion_listbox.delete(0, 'end')
        for item in matches:
            self.suggestion_listbox.insert('end', item)
        self.suggestion_popup.grid()

    def _hide_suggestions(self):
        focus_widget = self.focus_get()
        if focus_widget in {self.tickers_entry, self.suggestion_listbox}:
            return
        self.suggestion_popup.grid_remove()

    def _pick_suggestion(self, _event=None):
        if not self.suggestion_listbox.curselection():
            return
        value = self.suggestion_listbox.get(self.suggestion_listbox.curselection()[0])
        parts = [item.strip().upper() for item in self.tickers_var.get().split(',') if item.strip()]
        if parts:
            parts[-1] = value
        else:
            parts = [value]
        self.tickers_var.set(', '.join(dict.fromkeys(parts)) + ', ')
        self._hide_suggestions()
        self.tickers_entry.focus_set()
        self.tickers_entry.icursor('end')

    def _collect_config(self):
        weights = [float(item.strip()) for item in self.scalar_weights_var.get().split(',') if item.strip()]
        if len(weights) not in {0, 4}:
            raise ValueError('Для γ укажите четыре значения через запятую')
        config = OptimizationConfig(
            calib_window=int(self.calib_var.get()),
            cov_window=int(self.cov_var.get()),
            z_window=int(self.z_var.get()),
            horizon=int(self.horizon_var.get()),
            rebalance_every=int(self.rebalance_var.get()),
            w_min=float(self.wmin_var.get()),
            w_max=float(self.wmax_var.get()),
            leverage=float(self.leverage_var.get()),
            max_assets=int(self.max_assets_var.get()),
            a_max=float(self.a_max_var.get()),
            shrink_lambda=float(self.shrink_var.get()),
            mu_min=float(self.mu_min_var.get()),
            alpha_rank=float(self.alpha_rank_var.get()),
            beta_reg=float(self.beta_reg_var.get()),
            eta_stability=float(self.eta_var.get()),
            scalar_rho=float(self.scalar_rho_var.get()),
            no_trade_band=float(self.no_trade_band_var.get()),
            scalar_weights=weights or None,
            recalibrate_each_rebalance=bool(self.recalibrate_var.get()),
        )
        default_rates = {
            AssetType.EQUITY.value: RateSet(),
            AssetType.FUTURE.value: RateSet(),
            AssetType.PERPETUAL.value: RateSet(),
            AssetType.OTHER.value: RateSet(),
        }
        selected_type = self.default_type_var.get().strip().lower()
        default_rates[selected_type] = RateSet(
            fee=float(self.fee_var.get()),
            slippage=float(self.slippage_var.get()),
            tax=float(self.tax_var.get()),
            funding=float(self.funding_var.get()),
            borrow=float(self.borrow_var.get()),
            carry=float(self.carry_var.get()),
        )
        type_map = parse_symbol_mapping(self.asset_type_text.get('1.0', 'end'))
        rate_map_raw = parse_rate_mapping(self.asset_rate_text.get('1.0', 'end'))
        rate_map = {}
        for symbol, payload in rate_map_raw.items():
            rate_map[symbol] = RateSet(
                fee=payload.get('fee', default_rates[selected_type].fee),
                slippage=payload.get('slippage', default_rates[selected_type].slippage),
                tax=payload.get('tax', default_rates[selected_type].tax),
                funding=payload.get('funding', default_rates[selected_type].funding),
                borrow=payload.get('borrow', default_rates[selected_type].borrow),
                carry=payload.get('carry', default_rates[selected_type].carry),
            )
        cost_config = CostConfig(
            default_type=AssetType(selected_type),
            default_rates=default_rates,
            asset_types={key: AssetType(value) for key, value in type_map.items()},
            asset_rates=rate_map,
            initial_capital=float(self.initial_capital_var.get()),
        )
        tuning = TuningConfig(
            enabled_a=bool(self.optuna_a_var.get()),
            enabled_b=bool(self.optuna_b_var.get()),
            trials_a=int(self.trials_a_var.get()),
            trials_b=int(self.trials_b_var.get()),
        )
        return config, cost_config, tuning

    def _run_thread(self):
        if self.is_running or self.is_scanning:
            return
        try:
            config, cost_config, tuning = self._collect_config()
        except Exception as exc:
            messagebox.showerror('Ошибка параметров', str(exc))
            return
        tickers = [item.strip().upper() for item in self.tickers_var.get().split(',') if item.strip()]
        if not tickers:
            messagebox.showerror('Ошибка', 'Укажите хотя бы один тикер')
            return
        self.is_running = True
        self.run_button.configure(state='disabled')
        self.progress['value'] = 0
        self.log_records.clear()
        self._reset_live_views(tickers)
        self.last_run_context = {
            'tickers': tickers,
            'config': config,
            'cost_config': cost_config,
            'tuning': tuning,
        }
        self.queue.put({'kind': 'progress', 'p': 0, 'text': 'Запуск расчёта'})

        def worker():
            try:
                self.queue.put({'kind': 'log', 'msg': 'Загрузка данных по выбранному пулу', 'level': 'INFO'})
                load_tick = {'value': 0}

                def on_load_progress(text: str):
                    load_tick['value'] = min(12, load_tick['value'] + 1)
                    self.queue.put({'kind': 'progress', 'p': load_tick['value'], 'text': text})

                data = self.gateway.load_data_for_pool(tickers, use_cache=True, progress_cb=on_load_progress)
                self.queue.put({'kind': 'progress', 'p': max(load_tick['value'], 12), 'text': 'Данные загружены'})
                self.queue.put({'kind': 'log', 'msg': 'Данные загружены, запускается бэктест', 'level': 'INFO'})
                result = run_backtest(
                    data,
                    config,
                    cost_config,
                    tuning,
                    progress_cb=lambda percent, text: self.queue.put({'kind': 'progress', 'p': percent, 'text': text}),
                    log_cb=lambda msg, level='INFO': self.queue.put({'kind': 'log', 'msg': msg, 'level': level}),
                    snapshot_cb=lambda snapshot: self.queue.put({'kind': 'snapshot', 'snapshot': snapshot}),
                )
                self.queue.put({'kind': 'result', 'result': result})
            except Exception:
                self.queue.put({'kind': 'error', 'msg': traceback.format_exc().splitlines()[-1], 'trace': traceback.format_exc()})

        threading.Thread(target=worker, daemon=True).start()

    def _poll_queue(self):
        try:
            while True:
                item = self.queue.get_nowait()
                kind = item['kind']
                if kind == 'log':
                    self._log(item['msg'], item.get('level', 'INFO'))
                elif kind == 'progress':
                    self._set_progress(item.get('p'), item.get('text', ''))
                elif kind == 'snapshot':
                    self._pending_snapshot = item.get('snapshot')
                elif kind == 'scan_done':
                    self.is_scanning = False
                    self.scan_button.configure(state='normal')
                    count = int(item.get('count', 0))
                    self._set_progress(100, f'Сканирование завершено. Найдено тикеров: {count}')
                    self._log(f'Сканирование завершено. Найдено тикеров: {count}', 'READY')
                    self._refresh_suggestions()
                elif kind == 'scan_error':
                    self.is_scanning = False
                    self.scan_button.configure(state='normal')
                    self._log(item['msg'], 'ERROR')
                    if item.get('trace'):
                        self._log(item['trace'], 'ERROR')
                    messagebox.showerror('Ошибка', item['msg'])
                elif kind == 'result':
                    result = item['result']
                    self._render_result(result)
                    self.run_button.configure(state='normal')
                    self.is_running = False
                    self._set_progress(100, 'Расчёт завершён')
                    export_dir = self._export_result(result)
                    if export_dir is not None:
                        self._log(f'Артефакты расчёта сохранены: {export_dir}', 'READY')
                    self._log('Расчёт завершён', 'READY')
                elif kind == 'error':
                    self.run_button.configure(state='normal')
                    self.is_running = False
                    self._log(item['msg'], 'ERROR')
                    if item.get('trace'):
                        self._log(item['trace'], 'ERROR')
                    messagebox.showerror('Ошибка', item['msg'])
        except queue.Empty:
            pass

        if self._pending_snapshot is not None:
            now = time.time()
            if now - self._last_live_render_ts >= 0.55:
                self._consume_snapshot(self._pending_snapshot)
                self._render_live_state()
                self._pending_snapshot = None
                self._last_live_render_ts = now

        self.after(140, self._poll_queue)

    def _log(self, message: str, level: str = 'INFO'):
        stamp = time.strftime('%H:%M:%S')
        line = f'[{stamp}] {message}'
        self.log_records.append(line)
        self.log_widget.configure(state='normal')
        self.log_widget.insert('end', line + '\n', level)
        self.log_widget.see('end')
        self.log_widget.configure(state='disabled')

    def _set_progress(self, percent: int | None, text: str):
        if percent is not None:
            percent = max(0, min(100, int(percent)))
            self.progress['value'] = percent
            self.progress_label.configure(text=f'{percent}% — {text}')
        else:
            self.progress_label.configure(text=text)

    def _reset_live_views(self, tickers: list[str]):
        initial_capital = float(self.initial_capital_var.get())
        self.live_state = {
            'symbols': tickers[:],
            'equity_dates': [],
            'equity_values': [],
            'prices': pd.DataFrame(columns=tickers, dtype=float),
            'last_weights': np.zeros(len(tickers), dtype=float),
            'metrics': {
                'Статус расчёта': 'Подготовка к расчёту',
                'Текущий капитал': initial_capital,
                'Число активов': float(len(tickers)),
            },
            'metric_history': {},
            'metric_history_dates': {},
            'rebalance_dates': [],
            'latest_pareto': {'points': [], 'selected_index': 0, 'rebalance_date': None},
        }
        self._remember_metric_snapshot(pd.Timestamp.utcnow(), self.live_state['metrics'])
        self._render_live_state(force=True)

    def _remember_metric_snapshot(self, stamp: pd.Timestamp, metrics: dict):
        metric_history = self.live_state.setdefault('metric_history', {})
        metric_dates = self.live_state.setdefault('metric_history_dates', {})
        for key, value in metrics.items():
            if isinstance(value, (float, int, np.floating, np.integer)):
                history = metric_history.setdefault(key, [])
                dates = metric_dates.setdefault(key, [])
                if dates and dates[-1] == stamp:
                    history[-1] = float(value)
                else:
                    history.append(float(value))
                    dates.append(stamp)

    def _consume_snapshot(self, snapshot: dict):
        if not snapshot:
            return
        mode = snapshot.get('mode')
        if mode == 'init':
            symbols = list(snapshot.get('symbols', [])) or self.live_state.get('symbols', [])
            self.live_state = {
                'symbols': symbols,
                'equity_dates': [],
                'equity_values': [],
                'prices': pd.DataFrame(columns=symbols, dtype=float),
                'last_weights': np.zeros(len(symbols), dtype=float),
                'metrics': {},
                'metric_history': {},
                'metric_history_dates': {},
                'rebalance_dates': [],
                'latest_pareto': {'points': [], 'selected_index': 0, 'rebalance_date': None},
            }
        elif not self.live_state:
            self._reset_live_views(list(snapshot.get('symbols', [])))

        snapshot_date = pd.to_datetime(snapshot.get('equity_date') or snapshot.get('prices_date') or pd.Timestamp.utcnow())

        if snapshot.get('metrics'):
            metrics = dict(snapshot['metrics'])
            if snapshot.get('phase'):
                metrics = {'Статус расчёта': snapshot['phase'], **metrics}
            self.live_state['metrics'] = metrics
            self._remember_metric_snapshot(snapshot_date, metrics)

        if snapshot.get('equity_date') is not None and snapshot.get('equity_value') is not None:
            eq_date = pd.to_datetime(snapshot['equity_date'])
            eq_value = float(snapshot['equity_value'])
            if not self.live_state['equity_dates'] or eq_date != self.live_state['equity_dates'][-1]:
                self.live_state['equity_dates'].append(eq_date)
                self.live_state['equity_values'].append(eq_value)
            else:
                self.live_state['equity_values'][-1] = eq_value

        if snapshot.get('prices_date') is not None and snapshot.get('prices_row') is not None:
            row_date = pd.to_datetime(snapshot['prices_date'])
            row = pd.Series(snapshot['prices_row'], name=row_date, dtype=float)
            prices = self.live_state.get('prices')
            if prices is None or prices.empty:
                self.live_state['prices'] = pd.DataFrame([row])
            else:
                prices = prices.copy()
                prices.loc[row_date, row.index] = row.values
                self.live_state['prices'] = prices.sort_index()

        if snapshot.get('last_weights') is not None:
            self.live_state['last_weights'] = np.asarray(snapshot['last_weights'], dtype=float)

        if snapshot.get('rebalance_date') is not None:
            rebalance_date = pd.to_datetime(snapshot['rebalance_date'])
            rebalance_dates = self.live_state.setdefault('rebalance_dates', [])
            if not rebalance_dates or rebalance_date != rebalance_dates[-1]:
                rebalance_dates.append(rebalance_date)

        if snapshot.get('pareto_front') is not None:
            self.live_state['latest_pareto'] = {
                'points': list(snapshot.get('pareto_front', [])),
                'selected_index': int(snapshot.get('selected_front_index', 0) or 0),
                'rebalance_date': snapshot.get('rebalance_date'),
            }

    def _metric_items(self, metrics: dict) -> list[tuple[str, object]]:
        seen = set()
        ordered = []
        for key in self.main_metric_order:
            if key in metrics:
                ordered.append((key, metrics[key]))
                seen.add(key)
        for key, value in metrics.items():
            if key not in seen:
                ordered.append((key, value))
        return ordered

    def _ensure_metric_card(self, key: str) -> MetricCard:
        card = self.metric_cards.get(key)
        if card is None:
            card = MetricCard(self.metrics_scroll.inner, key, self._toggle_dashboard_metric)
            self.metric_cards[key] = card
        return card

    def _refresh_metric_cards(self):
        metrics = self.live_state.get('metrics', {})
        metric_history = self.live_state.get('metric_history', {})
        for row, (key, value) in enumerate(self._metric_items(metrics)):
            card = self._ensure_metric_card(key)
            card.grid(row=row, column=0, sticky='we', pady=(0, 6))
            history = metric_history.get(key, [])
            card.update_card(value, history, key in self.selected_dashboard_metrics)
        active_keys = {key for key, _ in self._metric_items(metrics)}
        for key, card in self.metric_cards.items():
            if key not in active_keys:
                card.grid_remove()

    def _toggle_dashboard_metric(self, metric_key: str):
        if metric_key in self.selected_dashboard_metrics:
            self.selected_dashboard_metrics = [item for item in self.selected_dashboard_metrics if item != metric_key]
        else:
            self.selected_dashboard_metrics.append(metric_key)
        self._refresh_metric_cards()
        self._refresh_dashboard_metrics()

    def _remove_dashboard_metric(self, metric_key: str):
        self.selected_dashboard_metrics = [item for item in self.selected_dashboard_metrics if item != metric_key]
        self._refresh_metric_cards()
        self._refresh_dashboard_metrics()

    def _refresh_dashboard_metrics(self):
        metrics = self.live_state.get('metrics', {})
        history = self.live_state.get('metric_history', {})
        wanted = [key for key in self.selected_dashboard_metrics if key in metrics]
        for idx, key in enumerate(wanted):
            panel = self.dashboard_metric_panels.get(key)
            if panel is None:
                panel = DashboardMetricPanel(self.dashboard_metrics_scroll.inner, key, self._remove_dashboard_metric)
                self.dashboard_metric_panels[key] = panel
            panel.grid(row=idx // 2, column=idx % 2, sticky='nsew', padx=4, pady=4)
            panel.update_panel(metrics[key], history.get(key, []))
        for key, panel in self.dashboard_metric_panels.items():
            if key not in wanted:
                panel.grid_remove()

    def _rerender_equity_views(self):
        if self.live_state:
            self._render_live_state(force=True)

    @staticmethod
    def _currency_formatter():
        return FuncFormatter(lambda value, _pos: '$' + f'{int(round(value)):,.0f}'.replace(',', ' '))

    @staticmethod
    def _apply_grid(ax, strong: bool = False):
        ax.minorticks_on()
        ax.grid(True, which='major', color='#aab4bf', alpha=0.52 if strong else 0.42, linewidth=0.9 if strong else 0.75)
        ax.grid(True, which='minor', color='#d5dbe1', alpha=0.32 if strong else 0.22, linewidth=0.55 if strong else 0.45)
        ax.set_axisbelow(True)

    def _draw_equity_trend(self, ax, dates, values):
        if len(dates) < 3 or len(values) < 3:
            return None
        series_index = pd.DatetimeIndex(pd.to_datetime(dates))
        if len(series_index) < 3:
            return None
        series_values = np.asarray(values, dtype=float)
        x = mdates.date2num(series_index.to_pydatetime())
        slope, intercept = np.polyfit(x, series_values, 1)
        median_step = np.median(np.diff(x)) if len(x) >= 2 else 1.0
        if not np.isfinite(median_step) or median_step <= 0:
            median_step = 1.0
        extension = 3
        x_future = np.concatenate([x, x[-1] + median_step * np.arange(1, extension + 1)])
        y_future = intercept + slope * x_future
        future_dates = mdates.num2date(x_future)
        ax.plot(future_dates, y_future, color='#ef6c00', linewidth=2.0, linestyle='--', alpha=0.92, label='Линия тренда')
        return future_dates, y_future

    def _plot_equity(
        self,
        ax,
        fig,
        canvas,
        dates,
        values,
        title: str,
        rebalance_dates: list[pd.Timestamp],
        show_rebalance_lines: bool = True,
        strong_grid: bool = False,
        show_trend_line: bool = True,
        color_periods: bool = False,
    ):
        ax.clear()
        trend_payload = None
        if len(dates) and len(values):
            series = pd.DataFrame({'date': pd.to_datetime(dates), 'equity': np.asarray(values, dtype=float)})
            base_color = '#1769aa'
            if not color_periods:
                sns.lineplot(data=series, x='date', y='equity', ax=ax, linewidth=2.25, color=base_color, label='Капитал')
            else:
                ax.plot(series['date'], series['equity'], color='#90a4ae', linewidth=1.3, alpha=0.42, label='Капитал')
                valid_rebalances = sorted(
                    pd.to_datetime(stamp) for stamp in rebalance_dates
                    if pd.to_datetime(stamp) > series['date'].iloc[0] and pd.to_datetime(stamp) <= series['date'].iloc[-1]
                )
                boundaries = [series['date'].iloc[0], *valid_rebalances, series['date'].iloc[-1]]
                for start_stamp, end_stamp in zip(boundaries[:-1], boundaries[1:]):
                    segment = series[(series['date'] >= start_stamp) & (series['date'] <= end_stamp)]
                    if len(segment) < 2:
                        continue
                    color = '#2e7d32' if float(segment['equity'].iloc[-1]) >= float(segment['equity'].iloc[0]) else '#c62828'
                    ax.plot(segment['date'], segment['equity'], color=color, linewidth=3.0, alpha=0.95)

            if show_trend_line:
                trend_payload = self._draw_equity_trend(ax, series['date'].tolist(), series['equity'].to_numpy())

            y_all = series['equity'].to_numpy(dtype=float)
            if trend_payload is not None:
                _, trend_values = trend_payload
                y_all = np.concatenate([y_all, np.asarray(trend_values, dtype=float)])

            y_min = float(np.nanmin(y_all))
            y_max = float(np.nanmax(y_all))
            span = max(y_max - y_min, max(abs(y_max), 1.0) * 0.06, 1.0)
            pad = span * 0.12
            lower = y_min - pad
            upper = y_max + pad
            ax.set_ylim(lower, upper)
            ax.fill_between(series['date'], series['equity'].to_numpy(), lower, alpha=0.12, color='#90caf9')

        if show_rebalance_lines:
            for stamp in rebalance_dates:
                ax.axvline(pd.to_datetime(stamp), color='#d32f2f', alpha=0.55, linewidth=1.35)
        ax.set_title(title, fontsize=14, weight='bold')
        ax.set_xlabel('Дата')
        ax.set_ylabel('Капитал, $')
        ax.yaxis.set_major_formatter(self._currency_formatter())
        self._apply_grid(ax, strong=strong_grid)
        fig.autofmt_xdate()
        handles, labels = ax.get_legend_handles_labels()
        if handles:
            ax.legend(loc='best', fontsize=8, frameon=True)
        canvas.draw_idle()

    def _plot_prices(self, ax, fig, canvas, prices_frame: pd.DataFrame, title: str, rebalance_dates: list[pd.Timestamp], compact: bool = False, show_rebalance_lines: bool = True, strong_grid: bool = False):
        ax.clear()
        if prices_frame is not None and not prices_frame.empty and len(prices_frame) > 1:
            ordered = prices_frame.sort_index()
            normalized = ordered / ordered.iloc[0]
            palette = sns.color_palette('tab10', n_colors=len(normalized.columns))
            for color, symbol in zip(palette, normalized.columns):
                series = normalized[symbol].dropna()
                if not series.empty:
                    ax.plot(series.index, series.values, linewidth=1.45 if not compact else 1.15, label=symbol, color=color)
        if show_rebalance_lines:
            for stamp in rebalance_dates:
                ax.axvline(pd.to_datetime(stamp), color='#d32f2f', alpha=0.22, linewidth=0.95)
        ax.set_title(title, fontsize=14, weight='bold')
        ax.set_xlabel('Дата')
        ax.set_ylabel('Нормированный уровень')
        if ax.get_legend_handles_labels()[0]:
            ax.legend(loc='upper left', ncol=2 if not compact else 1, fontsize=7 if compact else 8, frameon=True)
        self._apply_grid(ax, strong=strong_grid)
        fig.autofmt_xdate()
        canvas.draw_idle()

    def _plot_alloc(self, ax, canvas, labels: list[str], weights: list[float], title: str):
        ax.clear()
        if labels and weights:
            frame = pd.DataFrame({'symbol': labels, 'weight': weights})
            frame['color'] = np.where(frame['weight'] >= 0, '#2e7d32', '#c62828')
            sns.barplot(data=frame, x='symbol', y='weight', palette=frame['color'].tolist(), ax=ax)
            ax.axhline(0.0, color='#666666', linewidth=1)
            ax.tick_params(axis='x', rotation=45)
        ax.set_title(title, fontsize=14, weight='bold')
        ax.set_ylabel('Вес')
        ax.set_xlabel('')
        self._apply_grid(ax, strong=True)
        canvas.draw_idle()

    def _plot_pareto(self):
        latest = self.live_state.get('latest_pareto', {})
        points = latest.get('points', []) or []
        selected_index = int(latest.get('selected_index', 0) or 0)
        ax = self.pareto_ax
        ax.clear()
        if not points:
            ax.text2D(0.5, 0.5, 'Нет доступных точек фронта Парето', ha='center', va='center', transform=ax.transAxes)
            self.pareto_info.configure(text='Фронт Парето пока не построен')
            self.pareto_canvas.draw_idle()
            return
        frame = pd.DataFrame(points)
        cols = [col for col in ['risk', 'turnover', 'return', 'concentration'] if col in frame.columns]
        if len(cols) < 4:
            ax.text2D(0.5, 0.5, 'Недостаточно координат для 3D/4D-облака фронта', ha='center', va='center', transform=ax.transAxes)
            self.pareto_canvas.draw_idle()
            return
        frame['selected'] = False
        if 0 <= selected_index < len(frame):
            frame.loc[selected_index, 'selected'] = True
        color_values = frame['concentration'].to_numpy(dtype=float)
        rank_pct = frame['concentration'].rank(pct=True).to_numpy(dtype=float)
        size_values = 45 + 90 * rank_pct
        scatter = ax.scatter(
            frame['risk'].to_numpy(dtype=float),
            frame['turnover'].to_numpy(dtype=float),
            frame['return'].to_numpy(dtype=float),
            c=color_values,
            s=size_values,
            cmap='viridis',
            alpha=0.78,
            edgecolors='white',
            linewidths=0.5,
        )
        ax.scatter([0.0], [0.0], [0.0], s=85, color='black', marker='x', linewidths=1.6, label='Нулевая точка')
        if 0 <= selected_index < len(frame):
            selected = frame.iloc[selected_index]
            ax.scatter([selected['risk']], [selected['turnover']], [selected['return']], s=180, color='#d32f2f', edgecolors='black', linewidths=1.0)
        ax.set_title('Облако фронта Парето в 4D: риск × оборот × доходность, цвет/размер = концентрация', fontsize=12, weight='bold')
        ax.set_xlabel('Риск')
        ax.set_ylabel('Оборот')
        ax.set_zlabel('Доходность')
        ax.view_init(elev=24, azim=42)
        ax.xaxis._axinfo['grid']['linewidth'] = 0.8
        ax.yaxis._axinfo['grid']['linewidth'] = 0.8
        ax.zaxis._axinfo['grid']['linewidth'] = 0.8
        ax.xaxis._axinfo['grid']['color'] = (0.66, 0.70, 0.75, 0.60)
        ax.yaxis._axinfo['grid']['color'] = (0.66, 0.70, 0.75, 0.60)
        ax.zaxis._axinfo['grid']['color'] = (0.66, 0.70, 0.75, 0.60)
        if getattr(self, '_pareto_colorbar', None) is not None:
            try:
                self._pareto_colorbar.remove()
            except Exception:
                pass
            self._pareto_colorbar = None
        self._pareto_colorbar = self.pareto_fig.colorbar(scatter, ax=ax, pad=0.08, fraction=0.035)
        self._pareto_colorbar.set_label('Концентрация')
        selected_point = frame.iloc[min(max(selected_index, 0), len(frame) - 1)]
        rebalance_text = latest.get('rebalance_date') or '—'
        self.pareto_info.configure(
            text=(
                f'Последний фронт Парето: {len(frame)} точек | дата ребаланса: {rebalance_text}\n'
                f'Выбранная точка: return={selected_point.get("return", float("nan")):.4f}, '
                f'risk={selected_point.get("risk", float("nan")):.4f}, '
                f'turnover={selected_point.get("turnover", float("nan")):.4f}, '
                f'concentration={selected_point.get("concentration", float("nan")):.4f}'
            )
        )
        self.pareto_fig.tight_layout(rect=(0, 0.04, 1, 1))
        self.pareto_canvas.draw_idle()

    def _render_live_state(self, force: bool = False):
        state = self.live_state
        if not state:
            return
        self._refresh_metric_cards()
        self._refresh_dashboard_metrics()

        dates = pd.to_datetime(state.get('equity_dates', []))
        values = np.asarray(state.get('equity_values', []), dtype=float)
        prices_frame = state.get('prices', pd.DataFrame())
        weights = np.asarray(state.get('last_weights', []), dtype=float)
        symbols = state.get('symbols', list(prices_frame.columns) if prices_frame is not None else [])
        rebalance_dates = pd.to_datetime(state.get('rebalance_dates', [])) if state.get('rebalance_dates') else []

        labels = []
        plotted_weights = []
        if len(weights) and symbols:
            order = np.argsort(-np.abs(weights))
            for idx in order:
                if idx < len(symbols) and abs(weights[idx]) > 1e-6:
                    labels.append(symbols[idx])
                    plotted_weights.append(float(weights[idx]))

        self._plot_equity(
            self.equity_ax,
            self.equity_fig,
            self.equity_canvas,
            dates,
            values,
            'Кривая капитала',
            list(rebalance_dates),
            show_rebalance_lines=self.show_rebalance_lines_var.get(),
            strong_grid=True,
            show_trend_line=self.show_trend_line_var.get(),
            color_periods=self.show_period_outcomes_var.get(),
        )
        self._plot_prices(self.prices_ax, self.prices_fig, self.prices_canvas, prices_frame, 'Нормированные цены на тестовом интервале', list(rebalance_dates), show_rebalance_lines=True, strong_grid=True)
        self._plot_alloc(self.alloc_ax, self.alloc_canvas, labels, plotted_weights, 'Структура последнего портфеля')
        self._plot_equity(
            self.dashboard_equity_ax,
            self.dashboard_equity_fig,
            self.dashboard_equity_canvas,
            dates,
            values,
            'Капитал',
            list(rebalance_dates),
            show_rebalance_lines=False,
            strong_grid=True,
            show_trend_line=True,
            color_periods=False,
        )
        self._plot_prices(self.dashboard_prices_ax, self.dashboard_prices_fig, self.dashboard_prices_canvas, prices_frame, 'Цены активов', list(rebalance_dates), compact=True, show_rebalance_lines=False, strong_grid=True)
        self._plot_alloc(self.dashboard_alloc_ax, self.dashboard_alloc_canvas, labels, plotted_weights, 'Последний портфель')
        self._plot_pareto()

    def _render_result(self, result):
        symbols = list(result.prices_frame.columns)
        self.live_state = {
            'symbols': symbols,
            'equity_dates': pd.to_datetime(result.equity_curve.get('dates', [])).tolist(),
            'equity_values': [float(v) for v in result.equity_curve.get('values', [])],
            'prices': result.prices_frame.copy(),
            'last_weights': np.asarray(result.rebalance_history[-1]['weights'], dtype=float) if result.rebalance_history else np.zeros(len(symbols)),
            'metrics': result.metrics,
            'metric_history': self.live_state.get('metric_history', {}),
            'metric_history_dates': self.live_state.get('metric_history_dates', {}),
            'rebalance_dates': [pd.to_datetime(item['date']) for item in result.rebalance_history],
            'latest_pareto': {
                'points': result.rebalance_history[-1].get('pareto_front', []) if result.rebalance_history else [],
                'selected_index': int(result.rebalance_history[-1].get('selected_front_index', 0)) if result.rebalance_history else 0,
                'rebalance_date': str(result.rebalance_history[-1].get('date')) if result.rebalance_history else None,
            },
        }
        if not self.live_state['metric_history']:
            self._remember_metric_snapshot(pd.Timestamp.utcnow(), result.metrics)
        self._render_live_state(force=True)

    def _export_result(self, result):
        try:
            run_root = Path(self.base_dir) / 'runs' / time.strftime('run_%Y%m%d_%H%M%S')
            run_root.mkdir(parents=True, exist_ok=True)
            (run_root / 'metrics.json').write_text(json.dumps(result.metrics, ensure_ascii=False, indent=2), encoding='utf-8')
            pd.DataFrame(list(result.metrics.items()), columns=['metric', 'value']).to_csv(run_root / 'metrics.csv', index=False, encoding='utf-8-sig')
            pd.DataFrame({'date': result.equity_curve['dates'], 'equity': result.equity_curve['values']}).to_csv(run_root / 'equity.csv', index=False, encoding='utf-8-sig')
            result.prices_frame.to_csv(run_root / 'prices.csv', encoding='utf-8-sig')
            rebalance_rows = []
            for row in result.rebalance_history:
                base = {'date': str(row.get('date')), 'pareto_size': row.get('pareto_size'), 'skipped': row.get('skipped', False), 'selected_front_index': row.get('selected_front_index', 0)}
                diagnostics = row.get('diagnostics', {})
                for key, value in diagnostics.items():
                    base[f'diag_{key}'] = value
                for idx, weight in enumerate(row.get('weights', [])):
                    base[f'w_{idx}'] = float(weight)
                rebalance_rows.append(base)
            if rebalance_rows:
                pd.DataFrame(rebalance_rows).to_csv(run_root / 'rebalance_history.csv', index=False, encoding='utf-8-sig')
            if result.cost_history:
                pd.DataFrame(result.cost_history).to_csv(run_root / 'cost_history.csv', index=False, encoding='utf-8-sig')
            if result.level_a_history:
                level_rows = []
                for row in result.level_a_history:
                    base = {k: v for k, v in row.items() if k != 'weights'}
                    if 'weights' in row:
                        for idx, value in enumerate(row['weights']):
                            base[f'a_{idx}'] = float(value)
                    level_rows.append(base)
                pd.DataFrame(level_rows).to_csv(run_root / 'level_a_history.csv', index=False, encoding='utf-8-sig')
            ctx = self.last_run_context.copy()
            if ctx:
                serializable = {
                    'tickers': ctx.get('tickers', []),
                    'config': asdict(ctx['config']) if 'config' in ctx else {},
                    'tuning': asdict(ctx['tuning']) if 'tuning' in ctx else {},
                    'cost_config': {
                        'default_type': ctx['cost_config'].default_type.value if 'cost_config' in ctx else None,
                        'initial_capital': ctx['cost_config'].initial_capital if 'cost_config' in ctx else None,
                    } if 'cost_config' in ctx else {},
                }
                (run_root / 'run_context.json').write_text(json.dumps(serializable, ensure_ascii=False, indent=2), encoding='utf-8')
            (run_root / 'run.log').write_text('\n'.join(self.log_records), encoding='utf-8')
            self.equity_fig.savefig(run_root / 'equity_curve.png', dpi=180, bbox_inches='tight')
            self.prices_fig.savefig(run_root / 'normalized_prices.png', dpi=180, bbox_inches='tight')
            self.alloc_fig.savefig(run_root / 'last_portfolio.png', dpi=180, bbox_inches='tight')
            self.dashboard_equity_fig.savefig(run_root / 'dashboard_equity.png', dpi=180, bbox_inches='tight')
            self.dashboard_prices_fig.savefig(run_root / 'dashboard_prices.png', dpi=180, bbox_inches='tight')
            self.dashboard_alloc_fig.savefig(run_root / 'dashboard_portfolio.png', dpi=180, bbox_inches='tight')
            self.pareto_fig.savefig(run_root / 'pareto_fronts.png', dpi=180, bbox_inches='tight')
            return str(run_root)
        except Exception as exc:
            self._log(f'Не удалось экспортировать артефакты расчёта: {exc}', 'WARN')
            return None


def run():
    app = Application()
    app.mainloop()
