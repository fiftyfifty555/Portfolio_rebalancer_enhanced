from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd


FEATURES = [
    'SMA20',
    'EMA20',
    'MACD',
    'MACD_signal',
    'RSI',
    'BB_upper',
    'BB_lower',
    'STO_K',
    'STO_D',
    'ATR',
    'OBV',
    'ADX',
    'BB_width',
    'RV20',
    'RV60',
    'ROC20',
    'ROC60',
    'VOL_RATIO20',
]


def add_indicators(frame: pd.DataFrame) -> pd.DataFrame:
    data = frame.copy()
    close = data['Close'].astype(float)
    high = data['High'].astype(float)
    low = data['Low'].astype(float)
    volume = data['Volume'].astype(float)
    eps = 1e-12

    data['SMA20'] = close.rolling(20).mean()
    data['EMA20'] = close.ewm(span=20, adjust=False).mean()

    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    data['MACD'] = ema12 - ema26
    data['MACD_signal'] = data['MACD'].ewm(span=9, adjust=False).mean()

    delta = close.diff()
    up = delta.clip(lower=0)
    down = -delta.clip(upper=0)
    rs = up.rolling(14).mean() / (down.rolling(14).mean() + eps)
    data['RSI'] = 100.0 - 100.0 / (1.0 + rs)

    std20 = close.rolling(20).std(ddof=0)
    data['BB_upper'] = data['SMA20'] + 2.0 * std20
    data['BB_lower'] = data['SMA20'] - 2.0 * std20
    data['BB_width'] = (data['BB_upper'] - data['BB_lower']) / (data['SMA20'].abs() + eps)

    low14 = low.rolling(14).min()
    high14 = high.rolling(14).max()
    data['STO_K'] = (close - low14) / (high14 - low14 + eps) * 100.0
    data['STO_D'] = data['STO_K'].rolling(3).mean()

    tr = pd.concat(
        [
            high - low,
            (high - close.shift(1)).abs(),
            (low - close.shift(1)).abs(),
        ],
        axis=1,
    ).max(axis=1)
    data['ATR'] = tr.rolling(14).mean()

    direction = np.sign(close.diff().fillna(0.0))
    data['OBV'] = (direction * volume).cumsum()

    plus_dm = high.diff()
    minus_dm = -low.diff()
    plus_dm = plus_dm.where((plus_dm > minus_dm) & (plus_dm > 0.0), 0.0)
    minus_dm = minus_dm.where((minus_dm > plus_dm) & (minus_dm > 0.0), 0.0)
    atr14 = tr.rolling(14).mean()
    plus_di = 100.0 * plus_dm.rolling(14).mean() / (atr14 + eps)
    minus_di = 100.0 * minus_dm.rolling(14).mean() / (atr14 + eps)
    dx = 100.0 * (plus_di - minus_di).abs() / (plus_di + minus_di + eps)
    data['ADX'] = dx.rolling(14).mean()

    returns = close.pct_change()
    data['RV20'] = returns.rolling(20).std(ddof=0) * np.sqrt(20)
    data['RV60'] = returns.rolling(60).std(ddof=0) * np.sqrt(60)
    data['ROC20'] = close / (close.shift(20) + eps) - 1.0
    data['ROC60'] = close / (close.shift(60) + eps) - 1.0
    data['VOL_RATIO20'] = volume / (volume.rolling(20).mean() + eps)
    return data



def _add_indicators_for_group(item: tuple[str, pd.DataFrame]) -> pd.DataFrame:
    _, group = item
    return add_indicators(group.sort_values('Date').reset_index(drop=True))



def add_indicators_by_symbol(frame: pd.DataFrame, max_workers: int = 1) -> pd.DataFrame:
    groups = [(str(symbol), group.copy()) for symbol, group in frame.groupby('Symbol', sort=True)]
    if max_workers > 1 and len(groups) > 1:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            frames = list(executor.map(_add_indicators_for_group, groups))
    else:
        frames = [_add_indicators_for_group(item) for item in groups]
    out = pd.concat(frames, ignore_index=True)
    return out.sort_values(['Symbol', 'Date']).reset_index(drop=True)
