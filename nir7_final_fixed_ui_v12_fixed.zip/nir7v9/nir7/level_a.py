from __future__ import annotations

from dataclasses import replace
from typing import Dict, Optional

import numpy as np
import pandas as pd

from .indicators import FEATURES
from .models import OptimizationConfig
from .signals import SignalEngine
from .utils import normalize_l1


class LevelAOptimizer:
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.signal_engine = SignalEngine(config.z_window, config.z_clip, config.mu_min)

    def repair(self, weights: np.ndarray) -> np.ndarray:
        clipped = np.clip(weights, -self.config.a_max, self.config.a_max)
        return normalize_l1(clipped)

    def _prepare(self, frame: pd.DataFrame) -> dict[str, np.ndarray] | None:
        data = self.signal_engine.build_feature_frame(frame.copy())
        z_cols = [f'Z_{feature}' for feature in FEATURES]
        matrix = data[z_cols].to_numpy(dtype=float)
        future_return = data['Close'].shift(-self.config.horizon).to_numpy(dtype=float) / data['Close'].to_numpy(dtype=float) - 1.0
        mask = np.isfinite(matrix).all(axis=1) & np.isfinite(future_return)
        matrix = matrix[mask]
        future_return = future_return[mask]
        min_obs = max(self.config.folds_a * 10, len(FEATURES) * 8)
        if len(matrix) < min_obs:
            return None
        obs_index = np.arange(len(matrix), dtype=float)
        if self.config.recency_half_life <= 0:
            recency = np.ones(len(matrix), dtype=float)
        else:
            decay = np.log(2.0) / float(self.config.recency_half_life)
            recency = np.exp(decay * (obs_index - obs_index.max()))
        recency /= np.maximum(recency.sum(), 1e-12)
        fold_indices = [np.asarray(chunk, dtype=int) for chunk in np.array_split(np.arange(len(matrix), dtype=int), self.config.folds_a) if len(chunk)]
        fold_weights = np.array([
            float(recency[idx].sum()) for idx in fold_indices
        ], dtype=float)
        fold_weights /= np.maximum(fold_weights.sum(), 1e-12)
        return {
            'matrix': matrix,
            'future': future_return,
            'recency': recency,
            'fold_indices': np.array(fold_indices, dtype=object),
            'fold_weights': fold_weights,
        }

    @staticmethod
    def _spearman(signal: np.ndarray, future: np.ndarray) -> float:
        if len(signal) < 3:
            return 0.0
        order_signal = np.argsort(np.argsort(signal))
        order_future = np.argsort(np.argsort(future))
        x = order_signal.astype(float)
        y = order_future.astype(float)
        x -= x.mean()
        y -= y.mean()
        denom = np.sqrt(np.dot(x, x) * np.dot(y, y))
        if denom < 1e-12:
            return 0.0
        return float(np.dot(x, y) / denom)

    @staticmethod
    def _weighted_direction_accuracy(signal: np.ndarray, future: np.ndarray, weights: np.ndarray) -> float:
        if len(signal) == 0:
            return 0.0
        success = (np.sign(signal) == np.sign(future)).astype(float)
        denom = float(np.sum(weights))
        if denom < 1e-12:
            return float(np.mean(success))
        return float(np.dot(success, weights) / denom)

    def evaluate_prepared(self, prepared: dict[str, np.ndarray] | None, weights: np.ndarray) -> dict[str, float]:
        if prepared is None:
            return {'objective': -1e9, 'ic': 0.0, 'da': 0.0, 'stability_penalty': 0.0}
        score = prepared['matrix'] @ weights
        future = prepared['future']
        recency = prepared['recency']
        fold_scores: list[float] = []
        for fold_idx in prepared['fold_indices']:
            fold_idx = np.asarray(fold_idx, dtype=int)
            fold_signal = score[fold_idx]
            fold_future = future[fold_idx]
            fold_recency = recency[fold_idx]
            ic = self._spearman(fold_signal, fold_future)
            da = self._weighted_direction_accuracy(fold_signal, fold_future, fold_recency)
            fold_scores.append(self.config.alpha_rank * ic + (1.0 - self.config.alpha_rank) * da)
        if not fold_scores:
            return {'objective': -1e9, 'ic': 0.0, 'da': 0.0, 'stability_penalty': 0.0}
        fold_scores_arr = np.array(fold_scores, dtype=float)
        objective_core = float(np.dot(fold_scores_arr, prepared['fold_weights']))
        ic_full = self._spearman(score, future)
        da_full = self._weighted_direction_accuracy(score, future, recency)
        reg = self.config.beta_reg * float(np.sum(weights ** 2))
        stability_penalty = self.config.eta_stability * float(np.var(fold_scores_arr))
        objective = float(objective_core - reg - stability_penalty)
        return {'objective': objective, 'ic': ic_full, 'da': da_full, 'stability_penalty': stability_penalty}

    def evaluate(self, frame: pd.DataFrame, weights: np.ndarray) -> dict[str, float]:
        return self.evaluate_prepared(self._prepare(frame), weights)

    def optimize(self, frame: pd.DataFrame, seed: int, progress_cb: Optional[callable] = None) -> tuple[np.ndarray, dict[str, float]]:
        prepared = self._prepare(frame)
        if prepared is None:
            weights = np.ones(len(FEATURES), dtype=float) / len(FEATURES)
            return weights, {'objective': 0.0, 'ic': 0.0, 'da': 0.0, 'stability_penalty': 0.0}
        rng = np.random.default_rng(seed)
        k_features = len(FEATURES)

        def random_individual() -> np.ndarray:
            return self.repair(rng.normal(0.0, 1.0, size=k_features))

        def crossover(parent_a: np.ndarray, parent_b: np.ndarray) -> np.ndarray:
            alpha = self.config.blx_alpha
            low = np.minimum(parent_a, parent_b)
            high = np.maximum(parent_a, parent_b)
            span = high - low
            child = low - alpha * span + rng.random(k_features) * (span * (1.0 + 2.0 * alpha))
            return self.repair(child)

        def mutate(individual: np.ndarray) -> np.ndarray:
            out = individual.copy()
            mask = rng.random(k_features) < self.config.mutation_prob_a
            if mask.any():
                out[mask] += rng.normal(0.0, self.config.mutation_sigma_a, size=int(mask.sum()))
            return self.repair(out)

        def tournament(population: list[np.ndarray], fitness: np.ndarray) -> np.ndarray:
            indices = rng.integers(0, len(population), size=3)
            best_idx = max(indices, key=lambda idx: fitness[idx])
            return population[int(best_idx)]

        population = [random_individual() for _ in range(self.config.pop_size_a)]
        evaluations = [self.evaluate_prepared(prepared, individual) for individual in population]
        fitness = np.array([item['objective'] for item in evaluations], dtype=float)
        best_idx = int(np.argmax(fitness))
        best = population[best_idx].copy()
        best_eval = evaluations[best_idx]

        for generation in range(self.config.generations_a):
            elite_idx = np.argsort(fitness)[-self.config.elite_a :]
            new_population = [population[int(idx)].copy() for idx in elite_idx]
            while len(new_population) < self.config.pop_size_a:
                parent_a = tournament(population, fitness)
                parent_b = tournament(population, fitness)
                new_population.append(mutate(crossover(parent_a, parent_b)))
            population = new_population
            evaluations = [self.evaluate_prepared(prepared, individual) for individual in population]
            fitness = np.array([item['objective'] for item in evaluations], dtype=float)
            current_idx = int(np.argmax(fitness))
            if float(fitness[current_idx]) > best_eval['objective']:
                best = population[current_idx].copy()
                best_eval = evaluations[current_idx]
            if progress_cb is not None:
                progress_cb(generation + 1, self.config.generations_a, best_eval['objective'])
        return best, best_eval


class LevelATuner:
    def __init__(self, config: OptimizationConfig):
        self.config = config

    def tune(
        self,
        symbol_frames: Dict[str, pd.DataFrame],
        trials: int,
        seed: int,
        progress_cb: Optional[callable] = None,
    ) -> OptimizationConfig:
        import optuna

        optuna.logging.set_verbosity(optuna.logging.WARNING)
        symbols = list(symbol_frames.keys())[: min(6, len(symbol_frames))]
        sampler = optuna.samplers.TPESampler(seed=seed)
        study = optuna.create_study(direction='maximize', sampler=sampler)

        def objective(trial: optuna.Trial) -> float:
            candidate = replace(
                self.config,
                pop_size_a=trial.suggest_int('pop_size_a', 20, 56),
                generations_a=trial.suggest_int('generations_a', 18, 45),
                mutation_prob_a=trial.suggest_float('mutation_prob_a', 0.10, 0.35),
                mutation_sigma_a=trial.suggest_float('mutation_sigma_a', 0.03, 0.22),
                blx_alpha=trial.suggest_float('blx_alpha', 0.10, 0.50),
                beta_reg=trial.suggest_float('beta_reg', 0.05, 0.25),
                eta_stability=trial.suggest_float('eta_stability', 0.05, 0.40),
                a_max=trial.suggest_float('a_max', 0.20, 0.45),
            )
            try:
                optimizer = LevelAOptimizer(candidate)
                scores = []
                for offset, symbol in enumerate(symbols):
                    _, evaluation = optimizer.optimize(symbol_frames[symbol], seed + offset)
                    scores.append(evaluation['objective'])
                return float(np.mean(scores))
            except Exception:
                return -1e9

        for trial_idx in range(trials):
            study.optimize(objective, n_trials=1)
            if progress_cb is not None:
                progress_cb(trial_idx + 1, trials, study.best_value)
        best = study.best_params
        return replace(
            self.config,
            pop_size_a=best['pop_size_a'],
            generations_a=best['generations_a'],
            mutation_prob_a=best['mutation_prob_a'],
            mutation_sigma_a=best['mutation_sigma_a'],
            blx_alpha=best['blx_alpha'],
            beta_reg=best['beta_reg'],
            eta_stability=best['eta_stability'],
            a_max=best['a_max'],
        )
