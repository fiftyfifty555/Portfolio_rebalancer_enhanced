from __future__ import annotations

from dataclasses import replace
from typing import Optional

import numpy as np

from .costs import CostEngine
from .models import OptimizationConfig
from .pareto import crowding_distance, fast_nondominated_sort, scalarizing_choice
from .utils import max_drawdown, sharpe_ratio


class LevelBOptimizer:
    def __init__(self, config: OptimizationConfig, cost_engine: CostEngine):
        self.config = config
        self.cost_engine = cost_engine

    def repair(self, weights: np.ndarray) -> np.ndarray:
        clipped = np.clip(weights, self.config.w_min, self.config.w_max)
        if np.sum(np.abs(clipped) > 1e-8) > self.config.max_assets:
            top = np.argsort(-np.abs(clipped))[: self.config.max_assets]
            mask = np.zeros_like(clipped, dtype=bool)
            mask[top] = True
            clipped = np.where(mask, clipped, 0.0)
        gross = np.sum(np.abs(clipped))
        if gross > self.config.leverage:
            clipped = clipped * (self.config.leverage / (gross + 1e-12))
        net = np.sum(clipped)
        if net > 1.0:
            clipped = clipped / (net + 1e-12)
        return clipped

    def objective_vector(
        self,
        weights: np.ndarray,
        mu_hat: np.ndarray,
        covariance: np.ndarray,
        previous_weights: np.ndarray,
        symbols: list[str],
        prices: np.ndarray,
        quantities: np.ndarray,
        average_prices: np.ndarray,
        equity_pre: float,
    ) -> tuple[tuple[float, float, float, float], bool, dict[str, float]]:
        if np.any(weights < self.config.w_min) or np.any(weights > self.config.w_max):
            penalty = (1e9, 1e9, 1e9, 1e9)
            return penalty, False, {'return': -1e9, 'risk': 1e9, 'turnover': 1e9, 'concentration': 1e9, 'cost_ratio': 1e9}
        if np.sum(np.abs(weights) > 1e-8) > self.config.max_assets:
            penalty = (1e9, 1e9, 1e9, 1e9)
            return penalty, False, {'return': -1e9, 'risk': 1e9, 'turnover': 1e9, 'concentration': 1e9, 'cost_ratio': 1e9}
        if np.sum(np.abs(weights)) > self.config.leverage + 1e-12:
            penalty = (1e9, 1e9, 1e9, 1e9)
            return penalty, False, {'return': -1e9, 'risk': 1e9, 'turnover': 1e9, 'concentration': 1e9, 'cost_ratio': 1e9}
        if np.sum(weights) > 1.0 + 1e-12:
            penalty = (1e9, 1e9, 1e9, 1e9)
            return penalty, False, {'return': -1e9, 'risk': 1e9, 'turnover': 1e9, 'concentration': 1e9, 'cost_ratio': 1e9}
        cost_ratio, breakdown = self.cost_engine.expected_cost_ratio(
            symbols,
            prices,
            quantities,
            average_prices,
            target_weights=weights,
            equity_pre=equity_pre,
            horizon_days=self.config.horizon,
        )
        expected_return = float(np.dot(weights, mu_hat) - cost_ratio)
        variance = float(max(weights.T @ covariance @ weights, 0.0))
        risk = float(np.sqrt(variance))
        turnover = float(np.sum(np.abs(weights - previous_weights)))
        gross = float(np.sum(np.abs(weights)))
        concentration = 0.0 if gross < 1e-12 else float(np.sum((np.abs(weights) / gross) ** 2))
        diagnostics = {
            'return': expected_return,
            'risk': risk,
            'turnover': turnover,
            'concentration': concentration,
            'cost_ratio': cost_ratio,
            **{f'cost_{k}': v / max(equity_pre, 1e-12) for k, v in breakdown.items()},
        }
        return (-expected_return, risk, turnover, concentration), True, diagnostics

    def optimize(
        self,
        mu_hat: np.ndarray,
        covariance: np.ndarray,
        previous_weights: np.ndarray,
        symbols: list[str],
        prices: np.ndarray,
        quantities: np.ndarray,
        average_prices: np.ndarray,
        equity_pre: float,
        seed: int,
        progress_cb: Optional[callable] = None,
    ) -> tuple[np.ndarray, tuple[float, float, float, float], dict[str, float], int, dict[str, object]]:
        rng = np.random.default_rng(seed)
        n_assets = len(mu_hat)

        def random_weights() -> np.ndarray:
            weights = rng.uniform(self.config.w_min, self.config.w_max, size=n_assets)
            if n_assets > self.config.max_assets:
                top = rng.choice(n_assets, size=self.config.max_assets, replace=False)
                mask = np.zeros(n_assets, dtype=bool)
                mask[top] = True
                weights = np.where(mask, weights, 0.0)
            return self.repair(weights)

        def crossover(parent_a: np.ndarray, parent_b: np.ndarray) -> np.ndarray:
            lam = rng.random()
            return self.repair(lam * parent_a + (1.0 - lam) * parent_b)

        def mutate(individual: np.ndarray) -> np.ndarray:
            out = individual.copy()
            mask = rng.random(len(out)) < self.config.mutation_prob_b
            if mask.any():
                out[mask] += rng.normal(0.0, self.config.mutation_sigma_b, size=int(mask.sum()))
            return self.repair(out)

        def tournament(population: list[np.ndarray], objectives: list[tuple[float, ...]], ranks: list[int]) -> np.ndarray:
            candidates = rng.integers(0, len(population), size=2)
            left, right = int(candidates[0]), int(candidates[1])
            if ranks[left] < ranks[right]:
                return population[left]
            if ranks[right] < ranks[left]:
                return population[right]
            front = [idx for idx, value in enumerate(ranks) if value == ranks[left]]
            distances = crowding_distance(front, objectives)
            return population[left] if distances.get(left, 0.0) >= distances.get(right, 0.0) else population[right]

        population = [random_weights() for _ in range(self.config.pop_size_b)]
        evaluations = [
            self.objective_vector(individual, mu_hat, covariance, previous_weights, symbols, prices, quantities, average_prices, equity_pre)
            for individual in population
        ]
        objectives = [item[0] for item in evaluations]

        for generation in range(self.config.generations_b):
            fronts, ranks = fast_nondominated_sort(objectives)
            elite_indices = fronts[0][: self.config.elite_b]
            next_population = [population[idx].copy() for idx in elite_indices]
            while len(next_population) < self.config.pop_size_b:
                parent_a = tournament(population, objectives, ranks)
                parent_b = tournament(population, objectives, ranks)
                next_population.append(mutate(crossover(parent_a, parent_b)))
            combined = population + next_population
            combined_evals = [
                self.objective_vector(individual, mu_hat, covariance, previous_weights, symbols, prices, quantities, average_prices, equity_pre)
                for individual in combined
            ]
            combined_obj = [item[0] for item in combined_evals]
            fronts, _ = fast_nondominated_sort(combined_obj)
            new_population = []
            for front in fronts:
                if len(new_population) + len(front) <= self.config.pop_size_b:
                    new_population.extend([combined[idx] for idx in front])
                else:
                    distances = crowding_distance(front, combined_obj)
                    ordered = sorted(front, key=lambda idx: distances[idx], reverse=True)
                    need = self.config.pop_size_b - len(new_population)
                    new_population.extend([combined[idx] for idx in ordered[:need]])
                    break
            population = new_population
            evaluations = [
                self.objective_vector(individual, mu_hat, covariance, previous_weights, symbols, prices, quantities, average_prices, equity_pre)
                for individual in population
            ]
            objectives = [item[0] for item in evaluations]
            if progress_cb is not None:
                fronts, _ = fast_nondominated_sort(objectives)
                progress_cb(generation + 1, self.config.generations_b, len(fronts[0]))
        fronts, _ = fast_nondominated_sort(objectives)
        best_front = fronts[0]
        best_index = scalarizing_choice(best_front, objectives, self.config.scalar_weights, self.config.scalar_rho)
        front_payload = {
            'points': [evaluations[idx][2] for idx in best_front],
            'selected_index': int(best_front.index(best_index)) if best_index in best_front else 0,
            'size': int(len(best_front)),
        }
        return population[best_index], objectives[best_index], evaluations[best_index][2], len(best_front), front_payload


class LevelBTuner:
    def __init__(self, config: OptimizationConfig, cost_engine: CostEngine):
        self.config = config
        self.cost_engine = cost_engine

    def _evaluate_candidate(self, candidate: OptimizationConfig, validation_states: list[dict], seed: int) -> float:
        optimizer = LevelBOptimizer(candidate, self.cost_engine)
        equity = [1.0]
        previous_weights = np.zeros(len(validation_states[0]['symbols']), dtype=float)
        quantities = np.zeros(len(previous_weights), dtype=float)
        average_prices = np.zeros(len(previous_weights), dtype=float)
        cumulative_cost_ratio = 0.0
        turnovers: list[float] = []
        realized_daily_returns: list[float] = []
        for idx, state in enumerate(validation_states):
            weights, _, diagnostics, _, _ = optimizer.optimize(
                mu_hat=state['mu_hat'],
                covariance=state['covariance'],
                previous_weights=previous_weights,
                symbols=state['symbols'],
                prices=state['prices'],
                quantities=quantities,
                average_prices=average_prices,
                equity_pre=equity[-1],
                seed=seed + idx * 13,
            )
            cumulative_cost_ratio += float(diagnostics['cost_ratio'])
            turnovers.append(float(diagnostics['turnover']))
            previous_weights = weights.copy()
            for ret_vector in state['holding_returns']:
                port_ret = float(np.dot(weights, ret_vector))
                realized_daily_returns.append(port_ret)
                equity.append(equity[-1] * (1.0 + port_ret))
        eq = np.array(equity, dtype=float)
        daily = np.array(realized_daily_returns, dtype=float)
        sharpe = sharpe_ratio(daily)
        mdd = max_drawdown(eq)
        turnover_avg = float(np.mean(turnovers)) if turnovers else 0.0
        q_b = (
            sharpe
            - candidate.q_b_drawdown_weight * mdd
            - candidate.q_b_cost_weight * cumulative_cost_ratio
            - candidate.q_b_turnover_weight * turnover_avg
        )
        return float(q_b)

    def tune_on_validation(
        self,
        validation_states: list[dict],
        trials: int,
        seed: int,
        progress_cb: Optional[callable] = None,
    ) -> OptimizationConfig:
        import optuna

        if not validation_states:
            return self.config
        optuna.logging.set_verbosity(optuna.logging.WARNING)
        sampler = optuna.samplers.TPESampler(seed=seed)
        study = optuna.create_study(direction='maximize', sampler=sampler)

        def objective(trial: optuna.Trial) -> float:
            try:
                scalar_weights = [
                    trial.suggest_float('gamma_return', 0.9, 1.4),
                    trial.suggest_float('gamma_risk', 1.0, 1.5),
                    trial.suggest_float('gamma_turnover', 1.0, 1.6),
                    trial.suggest_float('gamma_concentration', 0.9, 1.3),
                ]
                candidate = replace(
                    self.config,
                    pop_size_b=trial.suggest_int('pop_size_b', 36, 88),
                    generations_b=trial.suggest_int('generations_b', 20, 56),
                    mutation_prob_b=trial.suggest_float('mutation_prob_b', 0.08, 0.28),
                    mutation_sigma_b=trial.suggest_float('mutation_sigma_b', 0.02, 0.10),
                    shrink_lambda=trial.suggest_float('shrink_lambda', 0.20, 0.85),
                    scalar_weights=scalar_weights,
                    q_b_drawdown_weight=trial.suggest_float('q_b_drawdown_weight', 0.8, 1.5),
                    q_b_cost_weight=trial.suggest_float('q_b_cost_weight', 0.5, 1.5),
                    q_b_turnover_weight=trial.suggest_float('q_b_turnover_weight', 0.4, 1.2),
                )
                return self._evaluate_candidate(candidate, validation_states, seed + trial.number * 101)
            except Exception:
                return -1e9

        for trial_idx in range(trials):
            study.optimize(objective, n_trials=1)
            if progress_cb is not None:
                progress_cb(trial_idx + 1, trials, study.best_value)
        best = study.best_params
        return replace(
            self.config,
            pop_size_b=best['pop_size_b'],
            generations_b=best['generations_b'],
            mutation_prob_b=best['mutation_prob_b'],
            mutation_sigma_b=best['mutation_sigma_b'],
            shrink_lambda=best['shrink_lambda'],
            scalar_weights=[best['gamma_return'], best['gamma_risk'], best['gamma_turnover'], best['gamma_concentration']],
            q_b_drawdown_weight=best['q_b_drawdown_weight'],
            q_b_cost_weight=best['q_b_cost_weight'],
            q_b_turnover_weight=best['q_b_turnover_weight'],
        )
