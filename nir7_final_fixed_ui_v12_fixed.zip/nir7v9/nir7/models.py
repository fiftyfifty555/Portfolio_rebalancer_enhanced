from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class AssetType(str, Enum):
    EQUITY = "equity"
    FUTURE = "future"
    PERPETUAL = "perpetual"
    OTHER = "other"


@dataclass(slots=True)
class RateSet:
    fee: float = 0.001
    slippage: float = 0.0
    tax: float = 0.13
    funding: float = 0.0
    borrow: float = 0.0
    carry: float = 0.0


@dataclass(slots=True)
class OptimizationConfig:
    train_ratio: float = 0.70
    calib_window: int = 500
    cov_window: int = 500
    z_window: int = 60
    horizon: int = 30
    rebalance_every: int = 30
    w_min: float = -0.20
    w_max: float = 0.20
    leverage: float = 0.80
    max_assets: int = 10
    a_max: float = 0.30
    z_clip: float = 3.0
    mu_min: float = 0.006
    alpha_rank: float = 0.60
    beta_reg: float = 0.18
    eta_stability: float = 0.30
    shrink_lambda: float = 0.50
    scalar_rho: float = 0.05
    scalar_weights: Optional[List[float]] = None
    q_b_drawdown_weight: float = 1.0
    q_b_cost_weight: float = 1.0
    q_b_turnover_weight: float = 0.75
    recency_half_life: int = 126
    no_trade_band: float = 0.08
    pop_size_a: int = 36
    generations_a: int = 32
    mutation_prob_a: float = 0.22
    mutation_sigma_a: float = 0.16
    blx_alpha: float = 0.30
    elite_a: int = 2
    folds_a: int = 4
    pop_size_b: int = 64
    generations_b: int = 48
    mutation_prob_b: float = 0.16
    mutation_sigma_b: float = 0.06
    elite_b: int = 4
    seed: int = 42
    recalibrate_each_rebalance: bool = True
    max_workers: int = field(default_factory=lambda: max(1, min(8, os.cpu_count() or 1)))


@dataclass(slots=True)
class TuningConfig:
    enabled_a: bool = False
    enabled_b: bool = False
    trials_a: int = 12
    trials_b: int = 10
    timeout_a: Optional[int] = None
    timeout_b: Optional[int] = None


@dataclass(slots=True)
class CostConfig:
    default_type: AssetType = AssetType.EQUITY
    default_rates: Dict[str, RateSet] = field(default_factory=dict)
    asset_types: Dict[str, AssetType] = field(default_factory=dict)
    asset_rates: Dict[str, RateSet] = field(default_factory=dict)
    initial_capital: float = 1_000_000.0

    def ensure_defaults(self) -> None:
        if self.default_rates:
            return
        self.default_rates = {
            AssetType.EQUITY.value: RateSet(fee=0.001, slippage=0.0005, tax=0.0),
            AssetType.FUTURE.value: RateSet(fee=0.0007, slippage=0.0003, carry=0.01),
            AssetType.PERPETUAL.value: RateSet(fee=0.0007, slippage=0.0004, funding=0.03),
            AssetType.OTHER.value: RateSet(fee=0.001, slippage=0.0005),
        }


@dataclass(slots=True)
class BacktestResult:
    metrics: Dict[str, float]
    equity_curve: Dict[str, List[float]]
    prices_frame: Any
    rebalance_history: List[dict]
    cost_history: List[dict]
    level_a_history: List[dict]
    export_dir: Optional[str] = None
