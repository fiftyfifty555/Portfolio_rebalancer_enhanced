from __future__ import annotations

import numpy as np


def fast_nondominated_sort(objectives: list[tuple[float, ...]]) -> tuple[list[list[int]], list[int]]:
    size = len(objectives)
    dominates_set = [[] for _ in range(size)]
    dominated_count = [0] * size
    rank = [0] * size
    fronts = [[]]
    def dominates(i: int, j: int) -> bool:
        left = objectives[i]
        right = objectives[j]
        le = all(left[k] <= right[k] for k in range(len(left)))
        lt = any(left[k] < right[k] for k in range(len(left)))
        return le and lt
    for i in range(size):
        for j in range(size):
            if i == j:
                continue
            if dominates(i, j):
                dominates_set[i].append(j)
            elif dominates(j, i):
                dominated_count[i] += 1
        if dominated_count[i] == 0:
            fronts[0].append(i)
    front_index = 0
    while fronts[front_index]:
        next_front = []
        for i in fronts[front_index]:
            for j in dominates_set[i]:
                dominated_count[j] -= 1
                if dominated_count[j] == 0:
                    rank[j] = front_index + 1
                    next_front.append(j)
        front_index += 1
        fronts.append(next_front)
    fronts.pop()
    return fronts, rank


def crowding_distance(front: list[int], objectives: list[tuple[float, ...]]) -> dict[int, float]:
    if not front:
        return {}
    n_objectives = len(objectives[0])
    distance = {idx: 0.0 for idx in front}
    for objective_idx in range(n_objectives):
        ordered = sorted(front, key=lambda idx: objectives[idx][objective_idx])
        minimum = objectives[ordered[0]][objective_idx]
        maximum = objectives[ordered[-1]][objective_idx]
        distance[ordered[0]] = float('inf')
        distance[ordered[-1]] = float('inf')
        if abs(maximum - minimum) < 1e-18:
            continue
        for position in range(1, len(ordered) - 1):
            left = objectives[ordered[position - 1]][objective_idx]
            right = objectives[ordered[position + 1]][objective_idx]
            distance[ordered[position]] += (right - left) / (maximum - minimum)
    return distance


def scalarizing_choice(front_indices: list[int], objectives: list[tuple[float, ...]], weights: list[float] | None, rho: float) -> int:
    if len(front_indices) == 1:
        return front_indices[0]
    values = np.array([objectives[idx] for idx in front_indices], dtype=float)
    mins = values.min(axis=0)
    maxs = values.max(axis=0)
    denom = np.where(np.abs(maxs - mins) < 1e-12, 1.0, maxs - mins)
    normalized = (values - mins) / denom
    gamma = np.ones(normalized.shape[1], dtype=float) if not weights else np.array(weights, dtype=float)
    if gamma.shape[0] != normalized.shape[1]:
        gamma = np.ones(normalized.shape[1], dtype=float)
    scaled = normalized * gamma.reshape(1, -1)
    score = np.max(scaled, axis=1) + rho * np.sum(scaled, axis=1)
    best_local = int(np.argmin(score))
    return front_indices[best_local]
