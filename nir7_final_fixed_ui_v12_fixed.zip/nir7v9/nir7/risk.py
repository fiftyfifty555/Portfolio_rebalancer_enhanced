from __future__ import annotations

import numpy as np
import pandas as pd


def sample_covariance(returns: pd.DataFrame) -> np.ndarray:
    if returns.empty:
        return np.zeros((0, 0), dtype=float)
    return returns.cov(ddof=1).to_numpy(dtype=float)


def shrinkage_covariance(returns: pd.DataFrame, shrink_lambda: float, eps: float = 1e-8) -> np.ndarray:
    sample = sample_covariance(returns)
    if sample.size == 0:
        return sample
    diag = np.diag(np.diag(sample))
    shrunk = (1.0 - shrink_lambda) * sample + shrink_lambda * diag
    shrunk = shrunk + np.eye(shrunk.shape[0]) * eps
    return shrunk
