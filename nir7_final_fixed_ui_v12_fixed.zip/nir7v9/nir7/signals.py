from __future__ import annotations

import numpy as np
import pandas as pd

from .indicators import FEATURES
from .utils import clipped_zscore


class SignalEngine:
    def __init__(self, z_window: int, z_clip: float, mu_min: float):
        self.z_window = z_window
        self.z_clip = z_clip
        self.mu_min = mu_min

    def build_feature_frame(self, frame: pd.DataFrame) -> pd.DataFrame:
        data = frame.copy()
        for feature in FEATURES:
            data[f'Z_{feature}'] = clipped_zscore(data[feature], self.z_window, self.z_clip)
        return data

    def score_row(self, row: pd.Series, weights: np.ndarray) -> float:
        z_values = np.array([row.get(f'Z_{feature}', np.nan) for feature in FEATURES], dtype=float)
        if np.isnan(z_values).any():
            return 0.0
        return float(np.dot(weights, z_values))

    def mu_scale(self, returns_window: pd.DataFrame) -> float:
        if returns_window.empty:
            return self.mu_min
        avg_abs = float(np.abs(returns_window.values).mean())
        return max(self.mu_min, avg_abs)

    def mu_from_score(self, score: float, mu_scale: float) -> float:
        return float(mu_scale * np.tanh(score))
