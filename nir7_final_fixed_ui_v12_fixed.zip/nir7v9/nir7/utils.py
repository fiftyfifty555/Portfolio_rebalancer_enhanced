from __future__ import annotations

import math
from typing import Dict, Iterable

import numpy as np
import pandas as pd


def normalize_l1(vector: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    denom = np.sum(np.abs(vector))
    if denom < eps:
        return np.zeros_like(vector)
    return vector / denom


def rolling_zscore(series: pd.Series, window: int) -> pd.Series:
    mean = series.rolling(window).mean()
    std = series.rolling(window).std(ddof=0)
    out = (series - mean) / (std + 1e-12)
    return out.replace([np.inf, -np.inf], np.nan)


def clipped_zscore(series: pd.Series, window: int, z_clip: float) -> pd.Series:
    z = rolling_zscore(series, window)
    return z.clip(-z_clip, z_clip)


def max_drawdown(equity: np.ndarray) -> float:
    peak = np.maximum.accumulate(equity)
    drawdown = 1.0 - equity / np.maximum(peak, 1e-12)
    return float(np.max(drawdown))


def cagr(equity: np.ndarray, periods_per_year: int = 252) -> float:
    if len(equity) < 2 or equity[0] <= 0 or equity[-1] <= 0:
        return 0.0
    years = (len(equity) - 1) / periods_per_year
    if years <= 0:
        return 0.0
    return float((equity[-1] / equity[0]) ** (1.0 / years) - 1.0)


def annualized_volatility(returns: np.ndarray, periods_per_year: int = 252) -> float:
    if len(returns) == 0:
        return 0.0
    return float(np.std(returns, ddof=0) * math.sqrt(periods_per_year))


def sharpe_ratio(returns: np.ndarray, periods_per_year: int = 252, risk_free_rate: float = 0.0) -> float:
    if len(returns) == 0:
        return 0.0
    excess = np.mean(returns) - risk_free_rate / periods_per_year
    sigma = np.std(returns, ddof=0)
    if sigma < 1e-12:
        return 0.0
    return float(excess / sigma * math.sqrt(periods_per_year))


def calmar_ratio(equity: np.ndarray, periods_per_year: int = 252) -> float:
    dd = max_drawdown(equity)
    if dd < 1e-12:
        return 0.0
    return cagr(equity, periods_per_year) / dd


def effective_positions(concentration: float) -> float:
    if concentration <= 1e-12:
        return 0.0
    return 1.0 / concentration


def direction_accuracy(signal: np.ndarray, future_returns: np.ndarray) -> float:
    if len(signal) == 0:
        return 0.0
    signal_sign = np.sign(signal)
    return_sign = np.sign(future_returns)
    return float(np.mean(signal_sign == return_sign))


def information_coefficient(signal: np.ndarray, future_returns: np.ndarray) -> float:
    if len(signal) < 3:
        return 0.0
    series = pd.DataFrame({'signal': signal, 'future': future_returns}).dropna()
    if len(series) < 3:
        return 0.0
    value = series['signal'].corr(series['future'], method='spearman')
    if pd.isna(value):
        return 0.0
    return float(value)


def parse_symbol_mapping(text: str) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for token in text.replace('\n', ',').split(','):
        token = token.strip()
        if not token or '=' not in token:
            continue
        left, right = token.split('=', 1)
        left = left.strip().upper()
        right = right.strip().lower()
        if left and right:
            result[left] = right
    return result


def parse_rate_mapping(text: str) -> Dict[str, Dict[str, float]]:
    result: Dict[str, Dict[str, float]] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or ':' not in line:
            continue
        symbol, payload = line.split(':', 1)
        symbol = symbol.strip().upper()
        row: Dict[str, float] = {}
        for token in payload.split(','):
            token = token.strip()
            if '=' not in token:
                continue
            key, value = token.split('=', 1)
            key = key.strip().lower()
            try:
                row[key] = float(value.strip())
            except ValueError:
                continue
        if symbol and row:
            result[symbol] = row
    return result


def to_weight_table(weights: np.ndarray, symbols: Iterable[str], threshold: float = 1e-6) -> list[tuple[str, float]]:
    pairs = [(symbol, float(weight)) for symbol, weight in zip(symbols, weights) if abs(weight) > threshold]
    return sorted(pairs, key=lambda item: abs(item[1]), reverse=True)
